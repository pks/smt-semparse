catch(call_with_time_limit(1,eval([0,-2.506130,answer(city(loc_2(stateid('virginia')))),answer(city(loc_2(stateid('virginia'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([1,-2.590160,answer(high_point_1(state(next_to_2(stateid('mississippi'))))),answer(high_point_1(state(next_to_2(stateid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([2,-1.944510,answer(river(loc_2(stateid('arkansas')))),answer(river(loc_2(stateid('arkansas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([3,-2.478160,answer(river(loc_2(stateid('colorado')))),answer(river(loc_2(stateid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([4,-2.456340,answer(capital(loc_2(stateid('texas')))),answer(capital(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([5,-3.301220,answer(highest(place(loc_2(state(stateid('oregon')))))),answer(highest(place(loc_2(state(stateid('oregon'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([6,-3.406480,answer(count(state(low_point_2(lower_2(low_point_1(stateid('alabama'))))))),answer(count(state(low_point_2(lower_2(low_point_1(stateid('alabama')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([7,-2.633690,answer(state(loc_2(countryid('usa')))),answer(state(loc_2(countryid('usa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([8,-2.409820,answer(city(loc_2(stateid('texas')))),answer(city(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([9,-2.452250,answer(city(loc_2(countryid('usa')))),answer(city(loc_2(countryid('usa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([10,-2.506130,answer(city(loc_2(stateid('virginia')))),answer(city(loc_2(stateid('virginia'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([11,-2.558090,answer(city(loc_2(stateid('texas')))),answer(city(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([12,-2.523050,answer(lake(loc_2(stateid('california')))),answer(lake(loc_2(stateid('california'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([13,-1.805030,answer(largest(state(all))),answer(largest(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([14,-2.674920,answer(longest(river(traverse_2(countryid('usa'))))),answer(longest(river(traverse_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([15,-2.571700,answer(count(river(loc_2(stateid('california'))))),answer(count(river(loc_2(stateid('california')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([16,-2.555500,answer(state(next_to_2(stateid('utah')))),answer(state(next_to_2(stateid('utah'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([17,-1.916310,answer(size(stateid('alaska'))),answer(size(stateid('alaska')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([18,-1.965910,answer(size(stateid('massachusetts'))),answer(size(stateid('massachusetts')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([19,-1.950440,answer(size(stateid('new mexico'))),answer(size(stateid('new mexico')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([20,-1.921380,answer(size(stateid('north dakota'))),answer(size(stateid('north dakota')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([21,-1.898940,answer(size(stateid('texas'))),answer(size(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([22,-2.561960,answer(size(city(cityid('new york', _)))),answer(size(city(cityid('new york',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([23,-2.673900,answer(elevation_1(highest(place(loc_2(state(all)))))),answer(elevation_1(highest(place(loc_2(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([24,-1.929460,answer(elevation_1(placeid('guadalupe peak'))),answer(elevation_1(placeid('guadalupe peak')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([25,-1.959710,answer(elevation_1(placeid('mount mckinley'))),answer(elevation_1(placeid('mount mckinley')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([26,-2.469390,answer(elevation_1(highest(place(loc_2(countryid('usa')))))),answer(elevation_1(highest(place(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([27,-2.528980,answer(elevation_1(highest(place(loc_2(stateid('montana')))))),answer(elevation_1(highest(place(loc_2(stateid('montana'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([28,-2.645690,answer(elevation_1(highest(place(loc_2(largest(state(all))))))),answer(elevation_1(highest(place(loc_2(largest(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([29,-2.544540,answer(elevation_1(highest(place(loc_2(stateid('alabama')))))),answer(elevation_1(highest(place(loc_2(stateid('alabama'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([30,-2.577180,answer(elevation_1(highest(place(loc_2(stateid('delaware')))))),answer(elevation_1(highest(place(loc_2(stateid('delaware'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([31,-2.579470,answer(elevation_1(highest(place(loc_2(stateid('florida')))))),answer(elevation_1(highest(place(loc_2(stateid('florida'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([32,-2.583550,answer(elevation_1(highest(place(loc_2(stateid('louisiana')))))),answer(elevation_1(highest(place(loc_2(stateid('louisiana'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([33,-1.909520,answer(size(stateid('alaska'))),answer(size(stateid('alaska')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([34,-1.892150,answer(size(stateid('texas'))),answer(size(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([35,-2.576120,answer(size(largest(city(loc_2(stateid('alaska')))))),answer(size(largest(city(loc_2(stateid('alaska'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([36,-1.930780,answer(len(riverid('rio grande'))),answer(len(riverid('rio grande')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([37,-2.458990,answer(len(river(riverid('colorado')))),answer(len(river(riverid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([38,-2.518500,answer(len(river(riverid('delaware')))),answer(len(river(riverid('delaware'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([39,-2.560100,answer(len(longest(river(loc_2(stateid('california')))))),answer(len(longest(river(loc_2(stateid('california'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([40,-2.520640,answer(len(longest(river(loc_2(countryid('usa')))))),answer(len(longest(river(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([41,-1.910550,answer(len(riverid('mississippi'))),answer(len(riverid('mississippi')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([42,-2.478930,answer(len(river(riverid('mississippi')))),answer(len(river(riverid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([43,-2.577310,answer(len(river(riverid('mississippi')))),answer(len(river(riverid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([44,-2.473800,answer(len(river(riverid('missouri')))),answer(len(river(riverid('missouri'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([45,-2.486470,answer(len(river(riverid('north platte')))),answer(len(river(riverid('north platte'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([46,-2.507020,answer(len(river(riverid('ohio')))),answer(len(river(riverid('ohio'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([47,-2.522170,answer(len(river(riverid('rio grande')))),answer(len(river(riverid('rio grande'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([48,-2.575590,answer(len(shortest(river(loc_2(countryid('usa')))))),answer(len(shortest(river(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([49,-2.461670,answer(count(major(city(loc_2(stateid('pennsylvania')))))),answer(count(major(city(loc_2(stateid('pennsylvania'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([50,-2.498760,answer(count(capital(loc_2(stateid('rhode island'))))),answer(capital(loc_2(stateid('rhode island'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([51,-2.588420,answer(count(city(loc_2(stateid('louisiana'))))),answer(count(city(loc_2(stateid('louisiana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([52,-2.541510,answer(count(city(loc_2(stateid('montana'))))),answer(count(city(loc_2(stateid('montana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([53,-2.520460,answer(count(city(loc_2(countryid('usa'))))),answer(count(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([54,-2.536790,answer(count(city(loc_2(countryid('usa'))))),answer(count(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([55,-2.531310,answer(count(city(loc_2(countryid('usa'))))),answer(count(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([56,-2.533720,answer(count(city(loc_2(countryid('usa'))))),answer(count(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([57,-2.486630,answer(count(city(loc_2(stateid('texas'))))),answer(count(city(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([58,-2.494520,answer(count(city(loc_2(countryid('usa'))))),answer(count(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([59,-3.323630,answer(count(intersection(city(cityid('austin', _)), loc_2(countryid('usa'))))),answer(count(intersection(city(cityid('austin',_)),loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([60,-3.034920,answer(population_1(largest(city(all)))),answer(population_1(largest(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([61,-1.802850,answer(population_1(stateid('alabama'))),answer(population_1(stateid('alabama')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([62,-1.864940,answer(population_1(cityid('boulder', _))),answer(population_1(cityid('boulder',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([63,-2.418060,answer(population_1(stateid('california'))),answer(population_1(stateid('california')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([64,-2.545260,answer(count(river(riverid('colorado')))),answer(count(river(riverid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([65,-2.388680,answer(population_1(cityid('montgomery', _))),answer(population_1(cityid('montgomery',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([66,-2.576580,answer(count(major(city(loc_2(stateid('arizona')))))),answer(count(major(city(loc_2(stateid('arizona'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([67,-2.557070,answer(count(major(city(loc_2(stateid('florida')))))),answer(count(major(city(loc_2(stateid('florida'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([68,-2.730610,answer(count(major(city(loc_2(state(next_to_2(stateid('nebraska')))))))),answer(count(major(city(loc_2(state(next_to_2(stateid('nebraska'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([69,-2.716000,answer(count(major(city(loc_2(state(next_to_2(stateid('utah')))))))),answer(count(major(city(loc_2(state(next_to_2(stateid('utah'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([70,-2.553470,answer(count(major(city(loc_2(stateid('texas')))))),answer(count(major(city(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([71,-2.343680,answer(count(major(city(all)))),answer(count(major(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([72,-2.546380,answer(count(major(city(loc_2(stateid('oregon')))))),answer(count(major(city(loc_2(stateid('oregon'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([73,-2.648810,answer(count(major(river(traverse_2(stateid('ohio')))))),answer(count(major(river(traverse_2(stateid('ohio'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([74,-2.750770,answer(population_1(state(stateid('nevada')))),answer(population_1(state(stateid('nevada'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([75,-2.418440,answer(population_1(stateid('iowa'))),answer(population_1(stateid('iowa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([76,-2.385750,answer(population_1(stateid('new york'))),answer(population_1(stateid('new york')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([77,-1.888020,answer(population_1(cityid('boulder', _))),answer(population_1(cityid('boulder',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([78,-2.422800,answer(population_1(cityid('austin', _))),answer(population_1(cityid('austin',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([79,-2.381010,answer(population_1(cityid('austin', 'tx'))),answer(population_1(cityid('austin','tx')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([80,-2.384400,answer(population_1(stateid('california'))),answer(population_1(stateid('california')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([81,-2.406160,answer(population_1(cityid('chicago', _))),answer(population_1(cityid('chicago',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([82,-2.406160,answer(population_1(cityid('detroit', _))),answer(population_1(cityid('detroit',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([83,-2.396000,answer(population_1(stateid('hawaii'))),answer(population_1(stateid('hawaii')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([84,-2.419040,answer(population_1(cityid('houston', _))),answer(population_1(cityid('houston',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([85,-2.432730,answer(population_1(cityid('kalamazoo', _))),answer(population_1(cityid('kalamazoo',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([86,-2.431290,answer(population_1(stateid('kansas'))),answer(population_1(stateid('kansas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([87,-2.375300,answer(population_1(cityid('minneapolis', 'mn'))),answer(population_1(cityid('minneapolis','mn')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([88,-2.412230,answer(population_1(stateid('mississippi'))),answer(population_1(stateid('mississippi')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([89,-2.397170,answer(population_1(stateid('montana'))),answer(population_1(stateid('montana')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([90,-2.432580,answer(population_1(stateid('new hampshire'))),answer(population_1(stateid('new hampshire')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([91,-2.389500,answer(population_1(stateid('new mexico'))),answer(population_1(stateid('new mexico')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([92,-2.375340,answer(population_1(stateid('new york'))),answer(population_1(stateid('new york')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([93,-2.381360,answer(population_1(stateid('rhode island'))),answer(population_1(stateid('rhode island')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([94,-2.406160,answer(population_1(cityid('riverside', _))),answer(population_1(cityid('riverside',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([95,-2.423120,answer(population_1(cityid('san francisco', _))),answer(population_1(cityid('san francisco',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([96,-2.387210,answer(population_1(stateid('south dakota'))),answer(population_1(stateid('south dakota')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([97,-2.391930,answer(population_1(cityid('spokane', 'wa'))),answer(population_1(cityid('spokane','wa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([98,-2.363850,answer(population_1(stateid('texas'))),answer(population_1(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([99,-3.311130,answer(population_1(largest(city(loc_2(state(stateid('new york'))))))),answer(population_1(largest(city(loc_2(state(stateid('new york')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([100,-2.596870,answer(population_1(capital(loc_2(stateid('georgia'))))),answer(population_1(capital(loc_2(stateid('georgia')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([101,-2.499870,answer(population_1(capital(loc_2(stateid('texas'))))),answer(population_1(capital(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([102,-2.870470,answer(population_1(smallest(state(next_to_2(stateid('wyoming')))))),answer(population_1(smallest(state(next_to_2(stateid('wyoming'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([103,-3.029890,answer(population_1(largest_one(density_1(state(all))))),answer(population_1(largest_one(density_1(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([104,-2.518160,answer(population_1(countryid('usa'))),answer(population_1(countryid('usa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([105,-2.397050,answer(population_1(stateid('washington'))),answer(population_1(stateid('washington')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([106,-2.358190,answer(population_1(cityid('washington', 'dc'))),answer(population_1(cityid('washington','dc')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([107,-2.422800,answer(population_1(cityid('austin', _))),answer(population_1(cityid('austin',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([108,-2.389240,answer(population_1(stateid('utah'))),answer(population_1(stateid('utah')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([109,-2.389240,answer(population_1(stateid('utah'))),answer(population_1(stateid('utah')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([110,-2.385310,answer(population_1(stateid('texas'))),answer(population_1(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([111,-2.387600,answer(count(river(riverid('colorado')))),answer(count(river(riverid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([112,-2.505450,answer(count(river(loc_2(stateid('colorado'))))),answer(count(river(loc_2(stateid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([113,-2.490890,answer(count(river(loc_2(stateid('colorado'))))),answer(count(river(loc_2(stateid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([114,-2.509810,answer(count(river(loc_2(stateid('iowa'))))),answer(count(river(loc_2(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([115,-2.493580,answer(count(river(loc_2(stateid('missouri'))))),answer(count(river(loc_2(stateid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([116,-2.543780,answer(count(river(loc_2(stateid('new york'))))),answer(count(river(loc_2(stateid('new york')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([117,-3.407230,answer(count(river(loc_2(most(state(loc_1(river(all)))))))),answer(count(river(loc_2(most(state(loc_1(river(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([118,-3.193470,answer(count(river(loc_2(state(loc_1(highest(place(all)))))))),answer(count(river(loc_2(state(loc_1(highest(place(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([119,-3.197540,answer(count(river(loc_2(largest_one(population_1(state(all))))))),answer(count(river(loc_2(largest_one(population_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([120,-2.456930,answer(count(river(loc_2(stateid('idaho'))))),answer(count(river(loc_2(stateid('idaho')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([121,-2.494360,answer(count(river(loc_2(stateid('texas'))))),answer(count(river(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([122,-2.496860,answer(count(river(loc_2(countryid('usa'))))),answer(count(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([123,-3.365560,answer(count(exclude(river(all), traverse_2(state(loc_1(capital(cityid('albany', _)))))))),answer(count(exclude(river(all),traverse_2(state(loc_1(capital(cityid('albany',_))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([124,-2.471360,answer(count(river(loc_2(stateid('alaska'))))),answer(count(river(loc_2(stateid('alaska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([125,-2.456980,answer(count(river(loc_2(stateid('colorado'))))),answer(count(river(loc_2(stateid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([126,-3.379370,answer(count(intersection(river(loc_2(stateid('texas'))), longer(riverid('red'))))),answer(count(intersection(river(loc_2(stateid('texas'))),longer(riverid('red')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([127,-2.032120,answer(count(river(loc_2(stateid('washington'))))),answer(count(river(loc_2(stateid('washington')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([128,-2.504580,answer(count(river(traverse_2(stateid('texas'))))),answer(count(river(traverse_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([129,-2.684170,answer(count(river(traverse_2(state(next_to_2(stateid('colorado'))))))),answer(count(river(traverse_2(state(next_to_2(stateid('colorado')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([130,-2.444290,answer(area_1(countryid('usa'))),answer(area_1(countryid('usa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([131,-2.523720,answer(count(state(loc_2(countryid('usa'))))),answer(count(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([132,-2.540700,answer(count(state(loc_2(countryid('usa'))))),answer(count(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([133,-2.587070,answer(count(state(next_to_2(major(river(all)))))),answer(count(state(next_to_2(major(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([134,-1.761640,answer(count(state(all))),answer(count(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([135,-2.585040,answer(count(state(loc_2(countryid('usa'))))),answer(count(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([136,-2.543200,answer(count(state(loc_2(countryid('usa'))))),answer(count(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([137,-2.022010,answer(count(state(next_to_2(stateid('alaska'))))),answer(count(state(next_to_2(stateid('alaska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([138,-2.467680,answer(count(state(next_to_2(state(all))))),answer(count(state(next_to_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([139,-3.129250,answer(count(state(intersection(next_to_2(stateid('colorado')), next_to_2(stateid('new mexico')))))),answer(count(state(intersection(next_to_2(stateid('colorado')),next_to_2(stateid('new mexico'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([140,-2.007940,answer(count(state(next_to_2(stateid('hawaii'))))),answer(count(state(next_to_2(stateid('hawaii')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([141,-2.039060,answer(count(state(next_to_2(stateid('iowa'))))),answer(count(state(next_to_2(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([142,-3.253910,answer(count(state(next_to_2(state(loc_1(capital(cityid('boston', _)))))))),answer(count(state(next_to_2(state(loc_1(capital(cityid('boston',_))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([143,-2.044560,answer(count(state(next_to_2(stateid('tennessee'))))),answer(count(state(next_to_2(stateid('tennessee')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([144,-1.952540,answer(count(state(next_to_2(stateid('texas'))))),answer(count(state(next_to_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([145,-2.564430,answer(count(state(next_to_2(largest(state(all)))))),answer(count(state(next_to_2(largest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([146,-2.570080,answer(count(state(next_to_2(river(riverid('mississippi')))))),answer(count(state(next_to_2(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([147,-3.270460,answer(count(state(next_to_2(most(state(next_to_2(state(all)))))))),answer(count(state(next_to_2(most(state(next_to_2(state(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([148,-2.812500,answer(count(state(next_to_2(largest_one(population_1(state(all))))))),answer(count(state(next_to_2(largest_one(population_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([149,-2.694180,answer(count(exclude(state(all), loc_1(river(all))))),answer(count(exclude(state(all),loc_1(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([150,-2.442050,answer(count(state(next_to_1(stateid('iowa'))))),answer(count(state(next_to_1(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([151,-2.525740,answer(count(state(next_to_1(stateid('missouri'))))),answer(count(state(next_to_1(stateid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([152,-2.534560,answer(count(state(next_to_1(stateid('tennessee'))))),answer(count(state(next_to_1(stateid('tennessee')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([153,-2.567520,answer(count(state(traverse_1(river(riverid('colorado')))))),answer(count(state(traverse_1(river(riverid('colorado'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([154,-2.627690,answer(count(state(traverse_1(river(riverid('colorado')))))),answer(count(state(traverse_1(river(riverid('colorado'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([155,-2.642000,answer(count(state(traverse_1(river(riverid('mississippi')))))),answer(count(state(traverse_1(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([156,-2.575430,answer(count(state(traverse_1(riverid('mississippi'))))),answer(count(state(traverse_1(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([157,-2.635080,answer(count(state(traverse_1(river(riverid('missouri')))))),answer(count(state(traverse_1(river(riverid('missouri'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([158,-2.455020,answer(count(state(loc_2(countryid('usa'))))),answer(count(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([159,-2.521580,answer(count(state(loc_1(city(cityid('rochester', _)))))),answer(count(state(loc_1(city(cityid('rochester',_))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([160,-2.561270,answer(count(state(loc_1(city(cityid('springfield', _)))))),answer(count(state(loc_1(city(cityid('springfield',_))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([161,-4.705370,answer(count(state(loc_1(place(higher_2(highest(place(loc_2(state(loc_1(largest(capital(city(loc_2(countryid('usa')))))))))))))))),answer(count(state(loc_1(place(higher_2(highest(place(loc_2(state(loc_1(largest(capital(city(loc_2(countryid('usa'))))))))))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([162,-2.531270,answer(count(state(loc_1(city(cityid('austin', _)))))),answer(count(state(loc_1(city(cityid('austin',_))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([163,-2.494420,answer(count(state(loc_1(city(cityid('springfield', _)))))),answer(count(state(loc_1(city(cityid('springfield',_))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([164,-2.537930,answer(count(state(loc_1(major(river(all)))))),answer(count(state(loc_1(major(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([165,-3.350700,answer(count(intersection(state(loc_2(countryid('usa'))), traverse_1(shortest(river(all)))))),answer(count(intersection(state(loc_2(countryid('usa'))),traverse_1(shortest(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([166,-2.352830,answer(population_1(stateid('texas'))),answer(population_1(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([167,-1.943000,answer(elevation_1(placeid('mount mckinley'))),answer(elevation_1(placeid('mount mckinley')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([168,-2.603360,answer(elevation_1(highest(place(loc_2(stateid('montana')))))),answer(elevation_1(highest(place(loc_2(stateid('montana'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([169,-2.567550,answer(state(loc_1(placeid('mount mckinley')))),answer(state(loc_1(placeid('mount mckinley'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([170,-2.734040,answer(state(loc_1(highest(place(loc_2(countryid('usa'))))))),answer(state(loc_1(highest(place(loc_2(countryid('usa')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([171,-1.985210,answer(state(loc_1(cityid('rochester', _)))),answer(state(loc_1(cityid('rochester',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([172,-1.919000,answer(count(state(next_to_1(stateid('iowa'))))),answer(count(state(next_to_1(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([173,-1.817180,answer(state(all)),answer(state(all))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([174,-2.434770,answer(lake(loc_2(countryid('usa')))),answer(lake(loc_2(countryid('usa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([175,-2.478160,answer(river(loc_2(stateid('colorado')))),answer(river(loc_2(stateid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([176,-2.522390,answer(capital(loc_2(countryid('usa')))),answer(capital(loc_2(countryid('usa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([177,-2.382970,answer(longest(river(loc_2(countryid('usa'))))),answer(longest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([178,-2.596080,answer(major(lake(loc_2(stateid('michigan'))))),answer(major(lake(loc_2(stateid('michigan')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([179,-2.623670,answer(major(river(loc_2(stateid('florida'))))),answer(major(river(loc_2(stateid('florida')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([180,-1.944510,answer(river(loc_2(stateid('arkansas')))),answer(river(loc_2(stateid('arkansas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([181,-2.725910,answer(exclude(state(all), next_to_2(state(all)))),answer(exclude(state(all),next_to_2(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([182,-1.822650,answer(population_1(cityid('boulder', _))),answer(population_1(cityid('boulder',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([183,-1.845730,answer(population_1(cityid('boulder', _))),answer(population_1(cityid('boulder',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([184,-1.967190,answer(count(state(next_to_2(stateid('iowa'))))),answer(count(state(next_to_2(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([185,-4.177180,answer(state(loc_1(lowest(place(loc_2(state(traverse_1(river(riverid('mississippi')))))))))),loc_2(state(traverse_1(river(answer(state(loc_1(lowest(place('mississippi')))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([186,-1.891860,answer(population_1(cityid('boulder', _))),answer(population_1(cityid('boulder',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([187,-1.911370,answer(population_1(cityid('boulder', _))),answer(population_1(cityid('boulder',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([188,-2.009170,answer(river(loc_2(stateid('new york')))),answer(river(loc_2(stateid('new york'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([189,-2.477710,answer(state(loc_1(capital(cityid('sacramento', _))))),answer(state(loc_1(capital(cityid('sacramento',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([190,-2.510420,answer(state(loc_1(cityid('san antonio', _)))),answer(state(loc_1(cityid('san antonio',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([191,-1.928290,answer(major(city(loc_2(stateid('colorado'))))),answer(major(city(loc_2(stateid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([192,-2.534510,answer(major(lake(loc_2(countryid('usa'))))),answer(major(lake(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([193,-2.463140,answer(largest_one(area_1(state(all)))),answer(largest_one(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([194,-1.963180,answer(state(next_to_2(stateid('iowa')))),answer(state(next_to_2(stateid('iowa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([195,-2.475240,answer(city(loc_2(stateid('texas')))),answer(city(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([196,-2.823880,answer(state(traverse_1(longest(river(loc_2(stateid('texas'))))))),answer(state(traverse_1(longest(river(loc_2(stateid('texas')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([197,-2.496100,answer(state(traverse_1(riverid('mississippi')))),answer(state(traverse_1(riverid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([198,-2.522090,answer(state(traverse_1(riverid('mississippi')))),answer(state(traverse_1(riverid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([199,-2.630300,answer(river(loc_2(stateid('texas')))),answer(river(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([200,-2.569450,answer(major(river(loc_2(stateid('texas'))))),answer(major(river(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([201,-2.525930,answer(longest(river(loc_2(stateid('texas'))))),answer(longest(river(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([202,-3.297710,answer(capital(city(loc_2(state(next_to_2(stateid('texas'))))))),answer(capital(city(loc_2(state(next_to_2(stateid('texas')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([203,-2.552800,answer(capital(city(loc_2(stateid('texas'))))),answer(capital(city(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([204,-2.616150,answer(capital(loc_2(state(next_to_2(stateid('missouri')))))),answer(capital(loc_2(state(next_to_2(stateid('missouri'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([205,-2.789210,answer(capital(loc_2(state(next_to_2(stateid('texas')))))),answer(capital(loc_2(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([206,-2.528350,answer(city(loc_2(stateid('california')))),answer(city(loc_2(stateid('california'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([207,-3.139790,answer(city(loc_2(state(traverse_1(riverid('mississippi')))))),answer(city(loc_2(state(traverse_1(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([208,-3.176730,answer(city(loc_2(state(loc_1(highest(place(all))))))),answer(city(loc_2(state(loc_1(highest(place(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([209,-2.553060,answer(highest(place(loc_2(state(all))))),answer(highest(place(loc_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([210,-2.666460,answer(highest(place(loc_2(state(next_to_2(stateid('mississippi'))))))),answer(highest(place(loc_2(state(next_to_2(stateid('mississippi')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([211,-2.635880,answer(lake(loc_2(state(next_to_2(stateid('texas')))))),answer(lake(loc_2(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([212,-3.384250,answer(largest(city(loc_2(state(next_to_2(largest(state(all)))))))),answer(largest(city(loc_2(state(next_to_2(largest(state(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([213,-2.509930,answer(major(city(loc_2(stateid('alabama'))))),answer(major(city(loc_2(stateid('alabama')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([214,-2.465930,answer(major(city(loc_2(stateid('alaska'))))),answer(major(city(loc_2(stateid('alaska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([215,-2.478910,answer(major(city(loc_2(stateid('california'))))),answer(major(city(loc_2(stateid('california')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([216,-2.512240,answer(major(city(loc_2(stateid('delaware'))))),answer(major(city(loc_2(stateid('delaware')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([217,-2.516320,answer(major(city(loc_2(stateid('kansas'))))),answer(major(city(loc_2(stateid('kansas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([218,-2.507960,answer(major(city(loc_2(stateid('missouri'))))),answer(major(city(loc_2(stateid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([219,-2.528080,answer(major(city(loc_2(stateid('new mexico'))))),answer(major(city(loc_2(stateid('new mexico')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([220,-2.502850,answer(major(city(loc_2(stateid('new york'))))),answer(major(city(loc_2(stateid('new york')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([221,-2.485740,answer(major(city(loc_2(stateid('north carolina'))))),answer(major(city(loc_2(stateid('north carolina')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([222,-2.494370,answer(major(city(loc_2(stateid('ohio'))))),answer(major(city(loc_2(stateid('ohio')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([223,-2.526070,answer(major(city(loc_2(stateid('oklahoma'))))),answer(major(city(loc_2(stateid('oklahoma')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([224,-2.474460,answer(major(city(loc_2(stateid('rhode island'))))),answer(major(city(loc_2(stateid('rhode island')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([225,-3.101920,answer(major(city(loc_2(state(traverse_1(riverid('mississippi'))))))),answer(major(city(loc_2(state(traverse_1(riverid('mississippi')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([226,-2.460640,answer(major(city(loc_2(stateid('texas'))))),answer(major(city(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([227,-2.499030,answer(major(city(loc_2(largest(state(all)))))),answer(major(city(loc_2(largest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([228,-3.136470,answer(major(city(loc_2(smallest(state(loc_2(countryid('usa')))))))),answer(major(city(loc_2(smallest(state(loc_2(countryid('usa'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([229,-2.638370,answer(major(city(loc_2(state(stateid('california')))))),answer(major(city(loc_2(state(stateid('california'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([230,-3.885130,answer(major(city(loc_2(state(traverse_1(major(river(loc_2(stateid('virginia')))))))))),answer(major(city(loc_2(state(traverse_1(major(river(loc_2(stateid('virginia'))))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([231,-2.469830,answer(major(city(loc_2(countryid('usa'))))),answer(major(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([232,-2.536330,answer(major(city(loc_2(stateid('vermont'))))),answer(major(city(loc_2(stateid('vermont')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([233,-2.496260,answer(major(city(loc_2(stateid('wyoming'))))),answer(major(city(loc_2(stateid('wyoming')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([234,-2.494200,answer(major(city(loc_2(stateid('texas'))))),answer(major(city(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([235,-2.477930,answer(major(city(loc_2(countryid('usa'))))),answer(major(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([236,-2.509440,answer(major(city(loc_2(countryid('usa'))))),answer(major(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([237,-2.478610,answer(major(lake(loc_2(countryid('usa'))))),answer(major(lake(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([238,-2.628650,answer(major(river(loc_2(stateid('ohio'))))),answer(major(river(loc_2(stateid('ohio')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([239,-2.614060,answer(major(river(loc_2(countryid('usa'))))),answer(major(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([240,-2.888910,answer(major(city(loc_2(stateid('illinois'))))),answer(major(city(loc_2(stateid('illinois')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([241,-2.434270,answer(state(next_to_2(stateid('michigan')))),answer(state(next_to_2(stateid('michigan'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([242,-2.510750,answer(density_1(state(all))),answer(density_1(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([243,-2.403550,answer(population_1(stateid('mississippi'))),answer(population_1(stateid('mississippi')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([244,-3.198690,answer(population_1(major(city(loc_2(stateid('montana')))))),answer(population_1(major(city(loc_2(stateid('montana'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([245,-3.199330,answer(population_1(state(traverse_1(river(riverid('mississippi')))))),answer(population_1(state(traverse_1(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([246,-3.199330,answer(population_1(state(traverse_1(river(riverid('mississippi')))))),answer(population_1(state(traverse_1(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([247,-3.101500,answer(population_1(state(traverse_1(riverid('mississippi'))))),answer(population_1(state(traverse_1(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([248,-3.101500,answer(population_1(state(traverse_1(riverid('mississippi'))))),answer(population_1(state(traverse_1(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([249,-2.644300,answer(population_1(state(next_to_2(stateid('texas'))))),answer(population_1(state(next_to_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([250,-2.797700,answer(population_1(major(city(loc_2(stateid('texas')))))),answer(population_1(major(city(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([251,-3.221220,answer(population_1(state(traverse_1(river(riverid('mississippi')))))),answer(population_1(state(traverse_1(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([252,-3.221220,answer(population_1(state(traverse_1(river(riverid('mississippi')))))),answer(population_1(state(traverse_1(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([253,-3.152760,answer(population_1(state(traverse_1(riverid('mississippi'))))),answer(population_1(state(traverse_1(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([254,-3.152760,answer(population_1(state(traverse_1(riverid('mississippi'))))),answer(population_1(state(traverse_1(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([255,-2.551670,answer(river(loc_2(stateid('alaska')))),answer(river(loc_2(stateid('alaska'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([256,-2.722100,answer(river(loc_2(state(stateid('indiana'))))),answer(river(loc_2(state(stateid('indiana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([257,-2.670210,answer(river(loc_2(state(stateid('texas'))))),answer(river(loc_2(state(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([258,-2.541390,answer(river(loc_2(stateid('montana')))),answer(river(loc_2(stateid('montana'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([259,-1.897090,answer(state(all)),answer(state(all))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([260,-3.333070,answer(state(next_to_2(largest_one(population_1(state(all)))))),answer(state(next_to_2(largest_one(population_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([261,-2.739580,answer(state(traverse_1(riverid('potomac')))),answer(state(traverse_1(riverid('potomac'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([262,-2.803360,answer(state(traverse_1(longest(river(all))))),answer(state(traverse_1(longest(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([263,-2.467050,answer(population_1(stateid('missouri'))),answer(population_1(stateid('missouri')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([264,-2.534460,answer(largest_one(population_1(capital(all)))),answer(largest_one(population_1(capital(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([265,-2.678430,answer(largest(capital(loc_2(countryid('usa'))))),answer(largest(capital(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([266,-2.474440,answer(city(loc_2(stateid('pennsylvania')))),answer(city(loc_2(stateid('pennsylvania'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([267,-1.995380,answer(city(loc_2(stateid('california')))),answer(city(loc_2(stateid('california'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([268,-3.073840,answer(largest_one(population_1(city(loc_2(stateid('texas')))))),answer(largest_one(population_1(city(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([269,-2.658670,answer(largest_one(population_1(city(loc_2(stateid('texas')))))),answer(largest_one(population_1(city(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([270,-2.478070,answer(largest_one(population_1(city(all)))),answer(largest_one(population_1(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([271,-2.542080,answer(smallest_one(population_1(city(all)))),answer(smallest_one(population_1(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([272,-2.512350,answer(largest_one(population_1(city(all)))),answer(largest_one(population_1(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([273,-3.231590,answer(largest_one(density_1(city(loc_2(countryid('usa')))))),answer(largest_one(density_1(city(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([274,-1.931270,answer(capital(loc_2(stateid('iowa')))),answer(capital(loc_2(stateid('iowa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([275,-2.854070,answer(capital(loc_2(state(loc_1(lowest(place(all))))))),answer(capital(loc_2(state(loc_1(lowest(place(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([276,-1.913380,answer(largest(capital(all))),answer(largest(capital(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([277,-2.507700,answer(state(next_to_2(stateid('california')))),answer(state(next_to_2(stateid('california'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([278,-2.480090,answer(area_1(stateid('alaska'))),answer(area_1(stateid('alaska')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([279,-2.596420,answer(sum(area_1(state(all)))),answer(sum(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([280,-2.472790,answer(area_1(stateid('california'))),answer(area_1(stateid('california')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([281,-2.466070,answer(area_1(stateid('florida'))),answer(area_1(stateid('florida')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([282,-2.480920,answer(area_1(stateid('idaho'))),answer(area_1(stateid('idaho')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([283,-2.488060,answer(area_1(stateid('maine'))),answer(area_1(stateid('maine')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([284,-2.337950,answer(area_1(stateid('maryland'))),answer(area_1(stateid('maryland')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([285,-2.481620,answer(area_1(stateid('new mexico'))),answer(area_1(stateid('new mexico')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([286,-2.489030,answer(area_1(stateid('ohio'))),answer(area_1(stateid('ohio')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([287,-2.557290,answer(area_1(cityid('seattle', _))),answer(area_1(cityid('seattle',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([288,-2.476050,answer(area_1(stateid('south carolina'))),answer(area_1(stateid('south carolina')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([289,-2.447410,answer(area_1(stateid('texas'))),answer(area_1(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([290,-2.500450,answer(area_1(largest(state(all)))),answer(area_1(largest(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([291,-2.501390,answer(area_1(smallest(state(all)))),answer(area_1(smallest(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([292,-3.247360,answer(area_1(state(loc_1(capital(cityid('albany', _)))))),answer(area_1(state(loc_1(capital(cityid('albany',_))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([293,-3.095170,answer(area_1(smallest_one(density_1(state(all))))),answer(area_1(smallest_one(density_1(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([294,-2.386690,answer(area_1(state(all))),answer(area_1(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([295,-2.674870,answer(area_1(state(stateid('texas')))),answer(area_1(state(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([296,-2.515110,answer(area_1(stateid('wisconsin'))),answer(area_1(stateid('wisconsin')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([297,-2.618590,answer(density_1(countryid('usa'))),answer(density_1(countryid('usa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([298,-2.461340,answer(density_1(stateid('pennsylvania'))),answer(density_1(stateid('pennsylvania')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([299,-3.085210,answer(density_1(countryid('usa'))),answer(density_1(countryid('usa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([300,-3.053100,answer(largest(city(loc_2(state(loc_1(river(all))))))),answer(largest(city(loc_2(state(loc_1(river(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([301,-2.586980,answer(largest(capital(city(loc_2(countryid('usa')))))),answer(largest(capital(city(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([302,-2.562450,answer(largest(city(loc_2(stateid('arizona'))))),answer(largest(city(loc_2(stateid('arizona')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([303,-2.564210,answer(largest(city(loc_2(stateid('georgia'))))),answer(largest(city(loc_2(stateid('georgia')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([304,-2.545470,answer(largest(city(loc_2(stateid('kansas'))))),answer(largest(city(loc_2(stateid('kansas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([305,-2.562580,answer(largest(city(loc_2(stateid('louisiana'))))),answer(largest(city(loc_2(stateid('louisiana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([306,-2.561450,answer(largest(city(loc_2(stateid('nebraska'))))),answer(largest(city(loc_2(stateid('nebraska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([307,-2.533200,answer(largest(city(loc_2(stateid('oregon'))))),answer(largest(city(loc_2(stateid('oregon')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([308,-2.476170,answer(largest(city(loc_2(stateid('texas'))))),answer(largest(city(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([309,-2.540650,answer(largest(city(loc_2(smallest(state(all)))))),answer(largest(city(loc_2(smallest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([310,-2.468010,answer(largest(city(loc_2(countryid('usa'))))),answer(largest(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([311,-2.483930,answer(largest(city(loc_2(countryid('usa'))))),answer(largest(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([312,-2.470160,answer(largest(city(loc_2(countryid('usa'))))),answer(largest(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([313,-2.526750,answer(largest(city(loc_2(stateid('wyoming'))))),answer(largest(city(loc_2(stateid('wyoming')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([314,-2.542170,answer(longest(river(loc_2(stateid('illinois'))))),answer(longest(river(loc_2(stateid('illinois')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([315,-1.879060,answer(largest(state(all))),answer(largest(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([316,-2.487130,answer(largest(state(loc_2(countryid('usa'))))),answer(largest(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([317,-2.481190,answer(largest(state(loc_2(countryid('usa'))))),answer(largest(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([318,-3.143450,answer(capital(city(loc_2(largest(state(loc_2(countryid('usa')))))))),answer(capital(city(loc_2(largest(state(loc_2(countryid('usa'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([319,-2.431650,answer(capital(loc_2(stateid('california')))),answer(capital(loc_2(stateid('california'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([320,-2.420480,answer(capital(loc_2(stateid('colorado')))),answer(capital(loc_2(stateid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([321,-2.493710,answer(capital(loc_2(stateid('georgia')))),answer(capital(loc_2(stateid('georgia'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([322,-2.472300,answer(capital(loc_2(stateid('hawaii')))),answer(capital(loc_2(stateid('hawaii'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([323,-2.482710,answer(capital(loc_2(stateid('illinois')))),answer(capital(loc_2(stateid('illinois'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([324,-2.448880,answer(capital(loc_2(stateid('indiana')))),answer(capital(loc_2(stateid('indiana'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([325,-2.439410,answer(capital(loc_2(stateid('iowa')))),answer(capital(loc_2(stateid('iowa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([326,-2.506950,answer(capital(loc_2(stateid('maine')))),answer(capital(loc_2(stateid('maine'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([327,-2.511860,answer(capital(loc_2(stateid('maryland')))),answer(capital(loc_2(stateid('maryland'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([328,-2.486370,answer(capital(loc_2(stateid('massachusetts')))),answer(capital(loc_2(stateid('massachusetts'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([329,-2.475890,answer(capital(loc_2(stateid('michigan')))),answer(capital(loc_2(stateid('michigan'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([330,-2.462020,answer(capital(loc_2(stateid('new hampshire')))),answer(capital(loc_2(stateid('new hampshire'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([331,-2.467350,answer(capital(loc_2(stateid('new jersey')))),answer(capital(loc_2(stateid('new jersey'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([332,-2.473380,answer(capital(loc_2(stateid('new york')))),answer(capital(loc_2(stateid('new york'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([333,-2.424890,answer(capital(loc_2(stateid('north dakota')))),answer(capital(loc_2(stateid('north dakota'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([334,-2.457060,answer(capital(loc_2(stateid('ohio')))),answer(capital(loc_2(stateid('ohio'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([335,-2.453340,answer(capital(loc_2(stateid('pennsylvania')))),answer(capital(loc_2(stateid('pennsylvania'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([336,-3.118020,answer(capital(loc_2(state(loc_1(city(cityid('durham', _))))))),answer(capital(loc_2(state(loc_1(city(cityid('durham',_)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([337,-2.388280,answer(capital(loc_2(stateid('texas')))),answer(capital(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([338,-2.530850,answer(capital(loc_2(state(stateid('alabama'))))),answer(capital(loc_2(state(stateid('alabama')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([339,-2.530840,answer(capital(loc_2(state(stateid('florida'))))),answer(capital(loc_2(state(stateid('florida')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([340,-2.430030,answer(capital(loc_2(largest(state(all))))),answer(capital(loc_2(largest(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([341,-2.460080,answer(capital(loc_2(smallest(state(all))))),answer(capital(loc_2(smallest(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([342,-2.447810,answer(capital(loc_2(state(stateid('texas'))))),answer(capital(loc_2(state(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([343,-3.206880,answer(capital(loc_2(most(state(next_to_2(state(all))))))),answer(capital(loc_2(most(state(next_to_2(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([344,-3.386420,answer(capital(loc_2(state(next_to_2(state(next_to_2(stateid('texas')))))))),answer(capital(loc_2(state(next_to_2(state(next_to_2(stateid('texas'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([345,-3.099900,answer(capital(loc_2(state(loc_1(highest(place(all))))))),answer(capital(loc_2(state(loc_1(highest(place(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([346,-3.065490,answer(capital(loc_2(state(loc_1(highest(place(all))))))),answer(capital(loc_2(state(loc_1(highest(place(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([347,-3.063730,answer(capital(loc_2(largest_one(population_1(state(all)))))),answer(capital(loc_2(largest_one(population_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([348,-3.017790,answer(capital(loc_2(largest_one(density_1(state(all)))))),answer(capital(loc_2(largest_one(density_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([349,-3.168640,answer(capital(loc_2(state(loc_1(longest(river(all))))))),answer(capital(loc_2(state(loc_1(longest(river(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([350,-3.056460,answer(capital(loc_2(largest_one(population_1(state(all)))))),answer(capital(loc_2(largest_one(population_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([351,-2.502630,answer(capital(loc_2(stateid('utah')))),answer(capital(loc_2(stateid('utah'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([352,-2.497580,answer(capital(loc_2(stateid('vermont')))),answer(capital(loc_2(stateid('vermont'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([353,-2.473350,answer(capital(loc_2(stateid('washington')))),answer(capital(loc_2(stateid('washington'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([354,-3.171170,answer(largest_one(population_1(city(loc_2(stateid('texas')))))),answer(largest_one(population_1(city(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([355,-2.584530,answer(smallest_one(population_1(city(all)))),answer(smallest_one(population_1(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([356,-2.469680,answer(sum(area_1(state(all)))),answer(sum(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([357,-2.371860,answer(sum(population_1(state(all)))),answer(sum(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([358,-2.480990,answer(density_1(stateid('texas'))),answer(density_1(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([359,-2.522720,answer(density_1(stateid('new york'))),answer(density_1(stateid('new york')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([360,-2.437520,answer(elevation_1(placeid('death valley'))),answer(elevation_1(placeid('death valley')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([361,-3.040450,answer(elevation_1(highest(place(loc_2(countryid('usa')))))),answer(elevation_1(highest(place(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([362,-2.460890,answer(elevation_1(placeid('mount mckinley'))),answer(elevation_1(placeid('mount mckinley')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([363,-2.849530,answer(elevation_1(highest(mountain(loc_2(stateid('texas')))))),answer(elevation_1(highest(mountain(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([364,-3.033570,answer(elevation_1(highest(place(loc_2(countryid('usa')))))),answer(elevation_1(highest(place(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([365,-2.512790,answer(high_point_1(stateid('wyoming'))),answer(high_point_1(stateid('wyoming')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([366,-2.511830,answer(highest(place(loc_2(stateid('new mexico'))))),answer(highest(place(loc_2(stateid('new mexico')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([367,-2.466800,answer(highest(place(loc_2(stateid('south carolina'))))),answer(highest(place(loc_2(stateid('south carolina')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([368,-2.465040,answer(highest(place(loc_2(stateid('texas'))))),answer(highest(place(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([369,-2.430710,answer(highest(place(loc_2(countryid('usa'))))),answer(highest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([370,-2.542860,answer(highest(mountain(loc_2(stateid('alaska'))))),answer(highest(mountain(loc_2(stateid('alaska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([371,-2.487540,answer(highest(mountain(loc_2(stateid('texas'))))),answer(highest(mountain(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([372,-2.532760,answer(highest(mountain(loc_2(countryid('usa'))))),answer(highest(mountain(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([373,-2.515510,answer(highest(mountain(loc_2(countryid('usa'))))),answer(highest(mountain(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([374,-2.480770,answer(highest(place(loc_2(stateid('colorado'))))),answer(highest(place(loc_2(stateid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([375,-2.544460,answer(highest(place(loc_2(stateid('delaware'))))),answer(highest(place(loc_2(stateid('delaware')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([376,-3.233650,answer(highest(place(loc_2(state(loc_1(place(elevation_2(0)))))))),answer(highest(place(loc_2(state(loc_1(place(elevation_2(0))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([377,-2.546750,answer(highest(place(loc_2(stateid('florida'))))),answer(highest(place(loc_2(stateid('florida')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([378,-2.513820,answer(highest(place(loc_2(stateid('iowa'))))),answer(highest(place(loc_2(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([379,-2.497100,answer(highest(place(loc_2(stateid('kansas'))))),answer(highest(place(loc_2(stateid('kansas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([380,-2.532440,answer(highest(place(loc_2(stateid('maine'))))),answer(highest(place(loc_2(stateid('maine')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([381,-2.469600,answer(highest(place(loc_2(stateid('montana'))))),answer(highest(place(loc_2(stateid('montana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([382,-2.428650,answer(highest(place(loc_2(stateid('nevada'))))),answer(highest(place(loc_2(stateid('nevada')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([383,-2.533630,answer(highest(place(loc_2(stateid('new mexico'))))),answer(highest(place(loc_2(stateid('new mexico')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([384,-2.494130,answer(highest(place(loc_2(stateid('ohio'))))),answer(highest(place(loc_2(stateid('ohio')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([385,-2.474220,answer(highest(place(loc_2(stateid('rhode island'))))),answer(highest(place(loc_2(stateid('rhode island')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([386,-2.661260,answer(highest(place(loc_2(state(next_to_2(stateid('georgia'))))))),answer(highest(place(loc_2(state(next_to_2(stateid('georgia')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([387,-2.438580,answer(highest(place(loc_2(stateid('texas'))))),answer(highest(place(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([388,-2.479970,answer(highest(place(loc_2(countryid('usa'))))),answer(highest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([389,-2.492640,answer(highest(place(loc_2(smallest(state(all)))))),answer(highest(place(loc_2(smallest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([390,-3.103520,answer(highest(place(loc_2(state(loc_1(capital(cityid('austin', _)))))))),answer(highest(place(loc_2(state(loc_1(capital(cityid('austin',_))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([391,-3.103440,answer(highest(place(loc_2(state(loc_1(capital(cityid('des moines', _)))))))),answer(highest(place(loc_2(state(loc_1(capital(cityid('des moines',_))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([392,-3.188160,answer(highest(place(loc_2(state(loc_1(capital(cityid('des moines', _)))))))),answer(highest(place(loc_2(state(loc_1(capital(cityid('des moines',_))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([393,-3.227420,answer(highest(place(loc_2(most(state(traverse_1(river(all)))))))),answer(highest(place(loc_2(most(state(traverse_1(river(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([394,-3.162110,answer(highest(place(loc_2(smallest_one(population_1(state(all))))))),answer(highest(place(loc_2(smallest_one(population_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([395,-2.724490,answer(highest(place(loc_2(state(next_to_2(stateid('colorado'))))))),answer(highest(place(loc_2(state(next_to_2(stateid('colorado')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([396,-2.455680,answer(highest(place(loc_2(countryid('usa'))))),answer(highest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([397,-2.477360,answer(highest(place(loc_2(countryid('usa'))))),answer(highest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([398,-2.447320,answer(highest(place(loc_2(countryid('usa'))))),answer(highest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([399,-2.518330,answer(highest(place(loc_2(stateid('virginia'))))),answer(highest(place(loc_2(stateid('virginia')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([400,-2.496030,answer(highest(place(loc_2(stateid('wyoming'))))),answer(highest(place(loc_2(stateid('wyoming')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([401,-3.118620,answer(highest(place(loc_2(largest_one(area_1(state(all))))))),answer(highest(place(loc_2(largest_one(area_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([402,-3.175730,answer(highest(place(loc_2(smallest_one(density_1(state(all))))))),answer(highest(place(loc_2(smallest_one(density_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([403,-2.507990,answer(highest(place(loc_2(countryid('usa'))))),answer(highest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([404,-1.944570,answer(largest(capital(all))),answer(largest(capital(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([405,-2.607740,answer(largest(capital(city(loc_2(countryid('usa')))))),answer(largest(capital(city(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([406,-3.143320,answer(largest(city(loc_2(state(next_to_2(stateid('texas'))))))),answer(largest(city(loc_2(state(next_to_2(stateid('texas')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([407,-2.526320,answer(largest(city(loc_2(stateid('alabama'))))),answer(largest(city(loc_2(stateid('alabama')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([408,-2.495290,answer(largest(city(loc_2(stateid('california'))))),answer(largest(city(loc_2(stateid('california')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([409,-2.532740,answer(largest(city(loc_2(stateid('michigan'))))),answer(largest(city(loc_2(stateid('michigan')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([410,-2.612930,answer(largest_one(population_1(city(loc_2(stateid('minnesota')))))),answer(largest_one(population_1(city(loc_2(stateid('minnesota'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([411,-2.524350,answer(largest(city(loc_2(stateid('missouri'))))),answer(largest(city(loc_2(stateid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([412,-2.487640,answer(largest(city(loc_2(stateid('rhode island'))))),answer(largest(city(loc_2(stateid('rhode island')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([413,-3.180750,answer(largest(city(loc_2(smallest(state(traverse_1(riverid('mississippi')))))))),answer(largest(city(loc_2(smallest(state(traverse_1(riverid('mississippi'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([414,-2.738470,answer(largest(city(loc_2(state(next_to_2(stateid('california'))))))),answer(largest(city(loc_2(state(next_to_2(stateid('california')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([415,-2.479580,answer(largest(city(loc_2(stateid('texas'))))),answer(largest(city(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([416,-3.205340,answer(largest(city(loc_2(smallest(state(loc_2(countryid('usa')))))))),answer(largest(city(loc_2(smallest(state(loc_2(countryid('usa'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([417,-2.550110,answer(largest(city(loc_2(stateid('wisconsin'))))),answer(largest(city(loc_2(stateid('wisconsin')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([418,-2.541310,answer(largest(city(loc_2(stateid('kansas'))))),answer(largest(city(loc_2(stateid('kansas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([419,-3.241830,answer(largest(state(traverse_1(riverid('rio grande'))))),answer(largest(state(traverse_1(riverid('rio grande')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([420,-2.687740,answer(longest(river(loc_2(state(stateid('washington')))))),answer(longest(river(loc_2(state(stateid('washington'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([421,-1.883720,answer(largest(state(all))),answer(largest(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([422,-2.579680,answer(largest(state(next_to_2(stateid('arkansas'))))),answer(largest(state(next_to_2(stateid('arkansas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([423,-2.505790,answer(largest(state(next_to_2(stateid('texas'))))),answer(largest(state(next_to_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([424,-2.585810,answer(largest_one(population_1(capital_1(state(all))))),answer(largest_one(population_1(capital_1(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([425,-2.475970,answer(largest(state(loc_2(countryid('usa'))))),answer(largest(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([426,-2.487460,answer(largest(state(loc_2(countryid('usa'))))),answer(largest(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([427,-2.525210,answer(largest(state(next_to_2(stateid('california'))))),answer(largest(state(next_to_2(stateid('california')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([428,-2.477270,answer(largest(state(next_to_2(stateid('texas'))))),answer(largest(state(next_to_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([429,-3.276670,answer(largest(state(next_to_2(largest_one(population_1(state(all))))))),answer(largest(state(next_to_2(largest_one(population_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([430,-3.840400,answer(largest(state(next_to_2(state(loc_1(lowest(place(loc_2(countryid('usa')))))))))),answer(largest(state(next_to_2(state(loc_1(lowest(place(loc_2(countryid('usa'))))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([431,-2.617430,answer(largest(state(traverse_1(river(riverid('mississippi')))))),answer(largest(state(traverse_1(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([432,-2.389400,answer(smallest_one(population_1(state(all)))),answer(smallest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([433,-2.486290,answer(len(river(riverid('colorado')))),answer(len(river(riverid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([434,-3.099390,answer(len(intersection(riverid('colorado'), river(loc_2(stateid('texas')))))),answer(len(intersection(riverid('colorado'),river(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([435,-3.064110,answer(len(longest(river(loc_2(countryid('usa')))))),answer(len(longest(river(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([436,-3.175120,answer(len(longest(river(traverse_2(stateid('texas')))))),answer(len(longest(river(traverse_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([437,-2.486830,answer(len(river(riverid('mississippi')))),answer(len(river(riverid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([438,-3.275580,answer(len(most(river(traverse_2(state(all)))))),answer(len(most(river(traverse_2(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([439,-3.886540,answer(len(most(river(traverse_2(state(all)))))),answer(len(most(river(traverse_2(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([440,-3.244810,answer(len(most(river(traverse_2(state(all)))))),answer(len(most(river(traverse_2(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([441,-3.172340,answer(len(most(river(traverse_2(state(all)))))),answer(len(most(river(traverse_2(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([442,-1.837250,answer(longest(river(all))),answer(longest(river(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([443,-2.496860,answer(longest(river(traverse_2(stateid('new york'))))),answer(longest(river(traverse_2(stateid('new york')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([444,-2.501490,answer(longest(river(loc_2(countryid('usa'))))),answer(longest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([445,-2.492120,answer(longest(river(loc_2(stateid('california'))))),answer(longest(river(loc_2(stateid('california')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([446,-2.535350,answer(longest(river(loc_2(stateid('florida'))))),answer(longest(river(loc_2(stateid('florida')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([447,-2.563010,answer(longest(river(loc_2(stateid('mississippi'))))),answer(longest(river(loc_2(stateid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([448,-2.520170,answer(longest(river(loc_2(stateid('new york'))))),answer(longest(river(loc_2(stateid('new york')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([449,-2.503190,answer(longest(river(loc_2(stateid('pennsylvania'))))),answer(longest(river(loc_2(stateid('pennsylvania')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([450,-2.459650,answer(longest(river(loc_2(stateid('texas'))))),answer(longest(river(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([451,-2.521550,answer(longest(river(loc_2(largest(state(all)))))),answer(longest(river(loc_2(largest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([452,-3.140210,answer(longest(river(loc_2(smallest(state(loc_2(countryid('usa')))))))),answer(longest(river(loc_2(smallest(state(loc_2(countryid('usa'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([453,-3.149860,answer(longest(river(loc_2(state(loc_1(highest(place(all)))))))),answer(longest(river(loc_2(state(loc_1(highest(place(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([454,-3.534760,answer(longest(river(loc_2(most(state(loc_1(major(city(all))))))))),answer(longest(river(loc_2(most(state(loc_1(major(city(all)))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([455,-3.233360,answer(longest(river(loc_2(state(next_to_2(stateid('nebraska'))))))),answer(longest(river(loc_2(state(next_to_2(stateid('nebraska')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([456,-2.445330,answer(longest(river(loc_2(countryid('usa'))))),answer(longest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([457,-2.491040,answer(longest(river(loc_2(countryid('usa'))))),answer(longest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([458,-3.136080,answer(longest(exclude(river(all), traverse_2(stateid('texas'))))),answer(longest(exclude(river(all),traverse_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([459,-3.212500,answer(longest(river(traverse_2(state(next_to_2(stateid('indiana'))))))),answer(longest(river(traverse_2(state(next_to_2(stateid('indiana')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([460,-2.498440,answer(longest(river(traverse_2(stateid('colorado'))))),answer(longest(river(traverse_2(stateid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([461,-4.118790,answer(longest(river(traverse_2(state(next_to_2(most(state(next_to_2(state(all)))))))))),answer(longest(river(traverse_2(state(next_to_2(most(state(next_to_2(state(all))))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([462,-3.214170,answer(longest(river(traverse_2(state(next_to_2(stateid('tennessee'))))))),answer(longest(river(traverse_2(state(next_to_2(stateid('tennessee')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([463,-2.476340,answer(lowest(place(loc_2(stateid('pennsylvania'))))),answer(lowest(place(loc_2(stateid('pennsylvania')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([464,-2.516270,answer(lowest(place(loc_2(stateid('arkansas'))))),answer(lowest(place(loc_2(stateid('arkansas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([465,-2.481710,answer(lowest(place(loc_2(stateid('california'))))),answer(lowest(place(loc_2(stateid('california')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([466,-2.570000,answer(lowest(place(loc_2(stateid('louisiana'))))),answer(lowest(place(loc_2(stateid('louisiana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([467,-2.548830,answer(lowest(place(loc_2(stateid('massachusetts'))))),answer(lowest(place(loc_2(stateid('massachusetts')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([468,-2.561130,answer(lowest(place(loc_2(stateid('mississippi'))))),answer(lowest(place(loc_2(stateid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([469,-2.448990,answer(lowest(place(loc_2(stateid('nebraska'))))),answer(lowest(place(loc_2(stateid('nebraska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([470,-2.516270,answer(lowest(place(loc_2(stateid('oregon'))))),answer(lowest(place(loc_2(stateid('oregon')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([471,-2.457750,answer(lowest(place(loc_2(stateid('texas'))))),answer(lowest(place(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([472,-2.637000,answer(lowest(place(loc_2(state(stateid('california')))))),answer(lowest(place(loc_2(state(stateid('california'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([473,-2.635160,answer(lowest(place(loc_2(state(stateid('texas')))))),answer(lowest(place(loc_2(state(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([474,-2.474850,answer(lowest(place(loc_2(countryid('usa'))))),answer(lowest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([475,-2.483940,answer(lowest(place(loc_2(countryid('usa'))))),answer(lowest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([476,-2.552660,answer(lowest(place(loc_2(stateid('wisconsin'))))),answer(lowest(place(loc_2(stateid('wisconsin')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([477,-3.448940,answer(lowest(place(loc_2(state(traverse_1(river(riverid('colorado')))))))),answer(lowest(place(loc_2(state(traverse_1(river(riverid('colorado'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([478,-2.508550,answer(lowest(place(loc_2(stateid('colorado'))))),answer(lowest(place(loc_2(stateid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([479,-3.137790,answer(lowest(place(loc_2(largest_one(area_1(state(all))))))),answer(lowest(place(loc_2(largest_one(area_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([480,-2.523930,answer(lowest(place(loc_2(countryid('usa'))))),answer(lowest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([481,-2.545700,answer(major(city(loc_2(stateid('montana'))))),answer(major(city(loc_2(stateid('montana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([482,-2.675950,answer(highest(place(loc_2(cityid('san francisco', _))))),answer(highest(place(loc_2(cityid('san francisco',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([483,-2.419840,answer(largest_one(density_1(state(loc_2(countryid('usa')))))),answer(largest_one(density_1(state(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([484,-2.536990,answer(largest_one(population_1(capital(loc_2(countryid('usa')))))),answer(largest_one(population_1(capital(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([485,-2.591060,answer(largest_one(population_1(state(next_to_2(stateid('oklahoma')))))),answer(largest_one(population_1(state(next_to_2(stateid('oklahoma'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([486,-2.370920,answer(largest_one(population_1(city(all)))),answer(largest_one(population_1(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([487,-2.461740,answer(largest_one(population_1(city(loc_2(stateid('texas')))))),answer(largest_one(population_1(city(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([488,-2.532650,answer(largest_one(population_1(city(loc_2(stateid('wyoming')))))),answer(largest_one(population_1(city(loc_2(stateid('wyoming'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([489,-2.346090,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([490,-2.498350,answer(largest_one(population_1(state(loc_2(countryid('usa')))))),answer(largest_one(population_1(state(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([491,-2.937490,answer(largest_one(population_1(state(traverse_1(riverid('mississippi')))))),answer(largest_one(population_1(state(traverse_1(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([492,-3.177680,answer(state(loc_1(lowest(place(all))))),answer(state(loc_1(lowest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([493,-2.621530,answer(count(state(next_to_2(stateid('kentucky'))))),answer(count(state(next_to_2(stateid('kentucky')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([494,-3.274300,answer(density_1(state(loc_1(capital(cityid('austin', _)))))),answer(density_1(state(loc_1(capital(cityid('austin',_))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([495,-2.518860,answer(density_1(stateid('maine'))),answer(density_1(stateid('maine')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([496,-2.500290,answer(density_1(stateid('south dakota'))),answer(density_1(stateid('south dakota')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([497,-2.470470,answer(density_1(stateid('texas'))),answer(density_1(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([498,-2.534830,answer(density_1(largest(state(all)))),answer(density_1(largest(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([499,-2.523030,answer(density_1(smallest(state(all)))),answer(density_1(smallest(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([500,-3.114200,answer(density_1(smallest_one(area_1(state(all))))),answer(density_1(smallest_one(area_1(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([501,-3.113390,answer(density_1(smallest_one(population_1(state(all))))),answer(density_1(smallest_one(population_1(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([502,-2.514710,answer(density_1(stateid('wyoming'))),answer(density_1(stateid('wyoming')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([503,-2.486190,answer(population_1(cityid('boston', _))),answer(population_1(cityid('boston',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([504,-2.493610,answer(population_1(stateid('alaska'))),answer(population_1(stateid('alaska')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([505,-2.501300,answer(population_1(stateid('arizona'))),answer(population_1(stateid('arizona')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([506,-2.494180,answer(population_1(cityid('atlanta', _))),answer(population_1(cityid('atlanta',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([507,-2.497500,answer(population_1(cityid('atlanta', 'ga'))),answer(population_1(cityid('atlanta','ga')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([508,-2.501660,answer(population_1(cityid('austin', _))),answer(population_1(cityid('austin',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([509,-2.442190,answer(population_1(cityid('austin', 'tx'))),answer(population_1(cityid('austin','tx')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([510,-2.474050,answer(population_1(cityid('boston', 'ma'))),answer(population_1(cityid('boston','ma')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([511,-2.449680,answer(population_1(cityid('boulder', _))),answer(population_1(cityid('boulder',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([512,-2.463250,answer(population_1(stateid('california'))),answer(population_1(stateid('california')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([513,-2.499470,answer(population_1(cityid('dallas', _))),answer(population_1(cityid('dallas',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([514,-2.479720,answer(population_1(cityid('denver', _))),answer(population_1(cityid('denver',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([515,-2.440860,answer(population_1(cityid('erie', 'pa'))),answer(population_1(cityid('erie','pa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([516,-2.474850,answer(population_1(stateid('hawaii'))),answer(population_1(stateid('hawaii')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([517,-2.493350,answer(population_1(cityid('houston', _))),answer(population_1(cityid('houston',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([518,-2.502880,answer(population_1(stateid('idaho'))),answer(population_1(stateid('idaho')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([519,-2.506240,answer(population_1(stateid('illinois'))),answer(population_1(stateid('illinois')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([520,-2.504870,answer(population_1(stateid('maine'))),answer(population_1(stateid('maine')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([521,-2.506130,answer(population_1(stateid('maryland'))),answer(population_1(stateid('maryland')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([522,-2.506960,answer(population_1(stateid('minnesota'))),answer(population_1(stateid('minnesota')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([523,-2.476020,answer(population_1(stateid('montana'))),answer(population_1(stateid('montana')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([524,-2.424640,answer(population_1(stateid('new mexico'))),answer(population_1(stateid('new mexico')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([525,-2.405210,answer(population_1(stateid('new york'))),answer(population_1(stateid('new york')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([526,-2.549400,answer(population_1(city(cityid('new york', _)))),answer(population_1(city(cityid('new york',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([527,-2.502890,answer(population_1(stateid('oregon'))),answer(population_1(stateid('oregon')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([528,-2.429160,answer(population_1(cityid('portland', 'me'))),answer(population_1(cityid('portland','me')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([529,-2.413660,answer(population_1(stateid('rhode island'))),answer(population_1(stateid('rhode island')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([530,-2.480530,answer(population_1(cityid('sacramento', _))),answer(population_1(cityid('sacramento',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([531,-2.463310,answer(population_1(cityid('san antonio', _))),answer(population_1(cityid('san antonio',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([532,-2.472680,answer(population_1(cityid('seattle', _))),answer(population_1(cityid('seattle',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([533,-2.442600,answer(population_1(cityid('seattle', 'wa'))),answer(population_1(cityid('seattle','wa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([534,-2.402990,answer(population_1(stateid('south dakota'))),answer(population_1(stateid('south dakota')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([535,-2.484360,answer(population_1(cityid('springfield', 'mo'))),answer(population_1(cityid('springfield','mo')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([536,-2.427810,answer(population_1(cityid('springfield', 'sd'))),answer(population_1(cityid('springfield','sd')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([537,-2.440860,answer(population_1(cityid('tempe', 'az'))),answer(population_1(cityid('tempe','az')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([538,-2.442710,answer(population_1(stateid('texas'))),answer(population_1(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([539,-3.064360,answer(population_1(capital(loc_2(largest(state(all)))))),answer(population_1(capital(loc_2(largest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([540,-3.773710,answer(population_1(capital(loc_2(largest(state(traverse_1(riverid('mississippi')))))))),answer(population_1(capital(loc_2(largest(state(traverse_1(riverid('mississippi'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([541,-3.151750,answer(population_1(capital(loc_2(smallest(state(all)))))),answer(population_1(capital(loc_2(smallest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([542,-3.608830,answer(population_1(largest(city(loc_2(largest_one(area_1(state(all)))))))),answer(population_1(largest(city(loc_2(largest_one(area_1(state(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([543,-2.437370,answer(population_1(largest(state(all)))),answer(population_1(largest(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([544,-3.129690,answer(population_1(largest(state(next_to_2(stateid('texas')))))),answer(population_1(largest(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([545,-2.849720,answer(population_1(major(city(loc_2(stateid('wisconsin')))))),answer(population_1(major(city(loc_2(stateid('wisconsin'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([546,-2.494410,answer(smallest(population_1(state(all)))),answer(smallest(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([547,-3.315060,answer(population_1(most(state(next_to_2(state(all)))))),answer(population_1(most(state(next_to_2(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([548,-3.072960,answer(population_1(largest_one(density_1(state(all))))),answer(population_1(largest_one(density_1(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([549,-3.140050,answer(population_1(largest_one(area_1(state(all))))),answer(population_1(largest_one(area_1(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([550,-2.471710,answer(population_1(cityid('tucson', _))),answer(population_1(cityid('tucson',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([551,-2.469790,answer(population_1(stateid('utah'))),answer(population_1(stateid('utah')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([552,-2.474090,answer(population_1(stateid('washington'))),answer(population_1(stateid('washington')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([553,-2.375310,answer(population_1(cityid('washington', 'dc'))),answer(population_1(cityid('washington','dc')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([554,-2.408070,answer(river(traverse_2(stateid('ohio')))),answer(river(traverse_2(stateid('ohio'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([555,-1.916070,answer(shortest(river(all))),answer(shortest(river(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([556,-2.533550,answer(shortest(river(loc_2(stateid('alaska'))))),answer(shortest(river(loc_2(stateid('alaska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([557,-2.544940,answer(shortest(river(loc_2(stateid('iowa'))))),answer(shortest(river(loc_2(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([558,-2.575310,answer(shortest(river(loc_2(stateid('nebraska'))))),answer(shortest(river(loc_2(stateid('nebraska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([559,-2.486260,answer(shortest(river(loc_2(stateid('texas'))))),answer(shortest(river(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([560,-2.468870,answer(shortest(river(loc_2(countryid('usa'))))),answer(shortest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([561,-2.518080,answer(shortest(river(loc_2(countryid('usa'))))),answer(shortest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([562,-2.489230,answer(shortest(river(loc_2(countryid('usa'))))),answer(shortest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([563,-2.513810,answer(size(stateid('california'))),answer(size(stateid('california')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([564,-2.517480,answer(size(stateid('florida'))),answer(size(stateid('florida')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([565,-2.442310,answer(size(stateid('texas'))),answer(size(stateid('texas')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([566,-2.587730,answer(size(capital(loc_2(stateid('texas'))))),answer(size(capital(loc_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([567,-3.095900,answer(size(largest(state(loc_2(countryid('usa')))))),answer(size(largest(state(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([568,-2.497840,answer(smallest(city(loc_2(stateid('alaska'))))),answer(smallest(city(loc_2(stateid('alaska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([569,-2.529250,answer(smallest(city(loc_2(stateid('arkansas'))))),answer(smallest(city(loc_2(stateid('arkansas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([570,-2.542630,answer(smallest(city(loc_2(stateid('hawaii'))))),answer(smallest(city(loc_2(stateid('hawaii')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([571,-2.530940,answer(smallest(city(loc_2(largest(state(all)))))),answer(smallest(city(loc_2(largest(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([572,-2.473490,answer(smallest(city(loc_2(countryid('usa'))))),answer(smallest(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([573,-2.489410,answer(smallest(city(loc_2(countryid('usa'))))),answer(smallest(city(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([574,-2.535240,answer(smallest(city(loc_2(stateid('washington'))))),answer(smallest(city(loc_2(stateid('washington')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([575,-3.192170,answer(smallest(city(loc_2(smallest(state(loc_2(countryid('usa')))))))),answer(smallest(city(loc_2(smallest(state(loc_2(countryid('usa'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([576,-2.588340,answer(smallest(state(next_to_2(stateid('ohio'))))),answer(smallest(state(next_to_2(stateid('ohio')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([577,-2.590230,answer(smallest(state(next_to_2(stateid('wyoming'))))),answer(smallest(state(next_to_2(stateid('wyoming')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([578,-2.350900,answer(smallest_one(area_1(state(all)))),answer(smallest_one(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([579,-2.489360,answer(smallest(state(loc_2(countryid('usa'))))),answer(smallest(state(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([580,-2.483760,answer(smallest(state(next_to_2(stateid('texas'))))),answer(smallest(state(next_to_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([581,-3.195460,answer(smallest(most(state(next_to_2(state(all)))))),answer(smallest(most(state(next_to_2(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([582,-3.024640,answer(smallest(state(traverse_1(river(riverid('mississippi')))))),answer(smallest(state(traverse_1(river(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([583,-3.071720,answer(smallest(state(traverse_1(longest(river(all)))))),answer(smallest(state(traverse_1(longest(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([584,-2.654090,answer(state(loc_1(highest(place(all))))),answer(state(loc_1(highest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([585,-3.160310,answer(state(loc_1(highest(place(loc_2(countryid('usa'))))))),answer(state(loc_1(highest(place(loc_2(countryid('usa')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([586,-2.502450,answer(largest_one(area_1(state(all)))),answer(largest_one(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([587,-3.113200,answer(largest_one(density_1(state(loc_2(countryid('usa')))))),answer(largest_one(density_1(state(loc_2(countryid('usa'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([588,-2.586810,answer(largest_one(density_1(state(all)))),answer(largest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([589,-2.508150,answer(state(loc_1(lowest(place(all))))),answer(state(loc_1(lowest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([590,-2.555320,answer(smallest_one(population_1(state(all)))),answer(smallest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([591,-2.557160,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([592,-2.522170,answer(smallest_one(area_1(state(all)))),answer(smallest_one(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([593,-2.482340,answer(highest(mountain(loc_2(countryid('usa'))))),answer(highest(mountain(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([594,-2.523810,answer(highest(mountain(loc_2(countryid('usa'))))),answer(highest(mountain(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([595,-2.458280,answer(area_1(countryid('usa'))),answer(area_1(countryid('usa')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([596,-3.189360,answer(sum(len(river(all)))),answer(sum(len(river(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([597,-3.216590,answer(sum(population_1(state(next_to_2(stateid('texas')))))),answer(sum(population_1(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([598,-1.924210,answer(len(riverid('mississippi'))),answer(len(riverid('mississippi')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([599,-2.504890,answer(major(city(loc_2(stateid('pennsylvania'))))),answer(major(city(loc_2(stateid('pennsylvania')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([600,-2.613680,answer(major(river(traverse_2(stateid('illinois'))))),answer(major(river(traverse_2(stateid('illinois')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([601,-2.071640,answer(mountain(loc_2(stateid('alaska')))),answer(mountain(loc_2(stateid('alaska'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([602,-1.976190,answer(river(traverse_2(stateid('kansas')))),answer(river(traverse_2(stateid('kansas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([603,-1.910370,answer(river(traverse_2(stateid('texas')))),answer(river(traverse_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([604,-2.609730,answer(most(river(traverse_2(state(all))))),answer(most(river(traverse_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([605,-2.774030,answer(longest(river(loc_2(countryid('usa'))))),answer(longest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([606,-1.932030,answer(river(traverse_2(stateid('illinois')))),answer(river(traverse_2(stateid('illinois'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([607,-2.575870,answer(most(river(traverse_2(state(all))))),answer(most(river(traverse_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([608,-2.878800,answer(river(traverse_2(most(state(loc_1(city(all))))))),answer(river(traverse_2(most(state(loc_1(city(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([609,-1.999660,answer(river(traverse_2(stateid('virginia')))),answer(river(traverse_2(stateid('virginia'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([610,-2.569750,answer(most(river(traverse_2(state(all))))),answer(most(river(traverse_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([611,-3.334800,answer(river(traverse_2(most(state(next_to_2(state(all))))))),answer(river(traverse_2(most(state(next_to_2(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([612,-2.010760,answer(river(loc_2(stateid('nevada')))),answer(river(loc_2(stateid('nevada'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([613,-2.511070,answer(river(loc_2(stateid('new mexico')))),answer(river(loc_2(stateid('new mexico'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([614,-1.979480,answer(river(loc_2(stateid('oregon')))),answer(river(loc_2(stateid('oregon'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([615,-2.594090,answer(river(loc_2(state(next_to_2(stateid('texas')))))),answer(river(loc_2(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([616,-1.907490,answer(river(loc_2(stateid('texas')))),answer(river(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([617,-2.016190,answer(river(loc_2(stateid('utah')))),answer(river(loc_2(stateid('utah'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([618,-2.517420,answer(river(loc_2(stateid('texas')))),answer(river(loc_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([619,-2.660760,answer(exclude(river(all), traverse_2(stateid('tennessee')))),answer(exclude(river(all),traverse_2(stateid('tennessee'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([620,-1.934550,answer(river(traverse_2(stateid('colorado')))),answer(river(traverse_2(stateid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([621,-1.970610,answer(river(traverse_2(stateid('missouri')))),answer(river(traverse_2(stateid('missouri'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([622,-2.714140,answer(river(traverse_2(state(next_to_1(stateid('alabama')))))),answer(river(traverse_2(state(next_to_1(stateid('alabama'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([623,-3.200360,answer(river(traverse_2(state(next_to_2(largest_one(population_1(state(all)))))))),answer(river(traverse_2(state(next_to_2(largest_one(population_1(state(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([624,-2.511970,answer(river(traverse_2(largest(state(all))))),answer(river(traverse_2(largest(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([625,-2.901670,answer(river(traverse_2(largest_one(population_1(state(all)))))),answer(river(traverse_2(largest_one(population_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([626,-1.976280,answer(river(traverse_2(stateid('arizona')))),answer(river(traverse_2(stateid('arizona'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([627,-2.553100,answer(river(traverse_2(cityid('austin', 'tx')))),answer(river(traverse_2(cityid('austin','tx'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([628,-1.936220,answer(river(traverse_2(stateid('colorado')))),answer(river(traverse_2(stateid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([629,-1.999710,answer(river(traverse_2(stateid('louisiana')))),answer(river(traverse_2(stateid('louisiana'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([630,-1.979850,answer(river(traverse_2(stateid('maine')))),answer(river(traverse_2(stateid('maine'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([631,-2.415870,answer(river(traverse_2(stateid('new york')))),answer(river(traverse_2(stateid('new york'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([632,-3.210800,answer(river(traverse_2(state(loc_1(lowest(place(loc_2(countryid('usa'))))))))),answer(river(traverse_2(state(loc_1(lowest(place(loc_2(countryid('usa')))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([633,-3.571440,answer(river(traverse_2(state(next_to_2(state(loc_1(capital(cityid('atlanta', _))))))))),answer(river(traverse_2(state(next_to_2(state(loc_1(capital(cityid('atlanta',_)))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([634,-2.472030,answer(river(traverse_2(stateid('west virginia')))),answer(river(traverse_2(stateid('west virginia'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([635,-3.334800,answer(river(traverse_2(most(state(next_to_2(state(all))))))),answer(river(traverse_2(most(state(next_to_2(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([636,-2.680570,answer(largest_one(population_1(state(next_to_2(stateid('nevada')))))),answer(largest_one(population_1(state(next_to_2(stateid('nevada'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([637,-1.977170,answer(state(next_to_2(stateid('michigan')))),answer(state(next_to_2(stateid('michigan'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([638,-2.608260,answer(most(state(next_to_2(state(all))))),answer(most(state(next_to_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([639,-2.005900,answer(state(next_to_2(stateid('new york')))),answer(state(next_to_2(stateid('new york'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([640,-2.598200,answer(fewest(state(next_to_2(state(all))))),answer(fewest(state(next_to_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([641,-3.893300,answer(fewest(state(next_to_2(exclude(exclude(state(all), stateid('alaska')), stateid('hawaii')))))),answer(fewest(state(next_to_2(exclude(exclude(state(all),stateid('alaska')),stateid('hawaii'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([642,-2.586180,answer(most(state(next_to_2(state(all))))),answer(most(state(next_to_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([643,-2.679180,answer(state(next_to_2(smallest_one(population_1(state(all)))))),answer(state(next_to_2(smallest_one(population_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([644,-2.573190,answer(state(loc_1(highest(place(loc_2(countryid('usa'))))))),answer(state(loc_1(highest(place(loc_2(countryid('usa')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([645,-3.128800,answer(state(loc_1(highest(place(loc_2(state(traverse_1(river(riverid('colorado')))))))))),answer(state(loc_1(highest(place(loc_2(state(traverse_1(river(riverid('colorado'))))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([646,-1.943230,answer(state(loc_1(highest(place(all))))),answer(state(loc_1(highest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([647,-2.122280,answer(exclude(state(all), loc_1(river(all)))),answer(exclude(state(all),loc_1(river(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([648,-2.562800,answer(state(loc_1(capital(cityid('salem', _))))),answer(state(loc_1(capital(cityid('salem',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([649,-2.558990,answer(state(loc_1(city(cityid('flint', _))))),answer(state(loc_1(city(cityid('flint',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([650,-2.806990,answer(state(loc_1(largest_one(population_1(city(all)))))),answer(state(loc_1(largest_one(population_1(city(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([651,-2.791910,answer(state(loc_1(largest_one(population_1(city(all)))))),answer(state(loc_1(largest_one(population_1(city(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([652,-2.518740,answer(largest_one(density_1(state(all)))),answer(largest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([653,-2.528010,answer(state(loc_1(highest(place(all))))),answer(state(loc_1(highest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([654,-2.494250,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([655,-2.449420,answer(largest_one(density_1(state(all)))),answer(largest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([656,-2.501130,answer(largest_one(area_1(state(all)))),answer(largest_one(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([657,-2.504510,answer(state(loc_1(largest(capital(all))))),answer(state(loc_1(largest(capital(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([658,-2.523580,answer(state(loc_1(largest(city(all))))),answer(state(loc_1(largest(city(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([659,-2.471860,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([660,-2.485200,answer(largest_one(density_1(state(all)))),answer(largest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([661,-2.465110,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([662,-2.483680,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([663,-2.569690,answer(state(loc_1(longest(river(all))))),answer(state(loc_1(longest(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([664,-2.450900,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([665,-2.617700,answer(most(state(loc_1(city(all))))),answer(most(state(loc_1(city(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([666,-2.771560,answer(most(state(loc_1(major(city(all)))))),answer(most(state(loc_1(major(city(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([667,-2.578240,answer(most(state(traverse_1(major(river(all)))))),answer(most(state(traverse_1(major(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([668,-2.506520,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([669,-2.578280,answer(most(state(loc_1(river(all))))),answer(most(state(loc_1(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([670,-2.428770,answer(most(state(traverse_1(river(all))))),answer(most(state(traverse_1(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([671,-2.597000,answer(state(loc_1(shortest(river(all))))),answer(state(loc_1(shortest(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([672,-2.478870,answer(smallest_one(area_1(state(all)))),answer(smallest_one(area_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([673,-2.720500,answer(state(loc_1(smallest(capital(all))))),answer(state(loc_1(smallest(capital(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([674,-2.510560,answer(smallest_one(population_1(state(all)))),answer(smallest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([675,-2.468190,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([676,-2.519910,answer(smallest_one(population_1(state(all)))),answer(smallest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([677,-2.483430,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([678,-1.982460,answer(state(loc_1(cityid('austin', _)))),answer(state(loc_1(cityid('austin',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([679,-2.530570,answer(state(loc_1(capital(cityid('austin', _))))),answer(state(loc_1(capital(cityid('austin',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([680,-2.009490,answer(state(loc_1(cityid('boston', _)))),answer(state(loc_1(cityid('boston',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([681,-2.480110,answer(state(loc_1(capital(cityid('columbus', _))))),answer(state(loc_1(capital(cityid('columbus',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([682,-1.969140,answer(state(loc_1(cityid('dallas', _)))),answer(state(loc_1(cityid('dallas',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([683,-2.545860,answer(state(loc_1(cityid('des moines', _)))),answer(state(loc_1(cityid('des moines',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([684,-2.005730,answer(state(loc_1(cityid('miami', _)))),answer(state(loc_1(cityid('miami',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([685,-2.005730,answer(state(loc_1(cityid('pittsburgh', _)))),answer(state(loc_1(cityid('pittsburgh',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([686,-1.866550,answer(largest(state(all))),answer(largest(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([687,-2.653880,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([688,-2.915660,answer(state(most(state(loc_1(river(all)))))),answer(state(most(state(loc_1(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([689,-2.692900,answer(largest_one(population_1(state(next_to_2(stateid('texas')))))),answer(largest_one(population_1(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([690,-2.675170,answer(largest(state(next_to_2(stateid('texas'))))),answer(largest(state(next_to_2(stateid('texas')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([691,-3.114500,answer(largest_one(population_1(state(traverse_1(riverid('mississippi')))))),answer(largest_one(population_1(state(traverse_1(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([692,-2.441220,answer(state(next_to_2(stateid('arizona')))),answer(state(next_to_2(stateid('arizona'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([693,-2.462890,answer(state(next_to_2(stateid('texas')))),answer(state(next_to_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([694,-2.490090,answer(state(next_to_2(stateid('mississippi')))),answer(state(next_to_2(stateid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([695,-1.999090,answer(state(next_to_2(stateid('alaska')))),answer(state(next_to_2(stateid('alaska'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([696,-1.987090,answer(state(next_to_2(stateid('arkansas')))),answer(state(next_to_2(stateid('arkansas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([697,-1.997490,answer(state(next_to_2(stateid('delaware')))),answer(state(next_to_2(stateid('delaware'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([698,-1.999890,answer(state(next_to_2(stateid('florida')))),answer(state(next_to_2(stateid('florida'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([699,-2.008370,answer(state(next_to_2(stateid('georgia')))),answer(state(next_to_2(stateid('georgia'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([700,-2.003990,answer(state(next_to_2(stateid('hawaii')))),answer(state(next_to_2(stateid('hawaii'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([701,-1.989190,answer(state(next_to_2(stateid('indiana')))),answer(state(next_to_2(stateid('indiana'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([702,-2.059610,answer(state(next_to_2(stateid('kentucky')))),answer(state(next_to_2(stateid('kentucky'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([703,-1.977170,answer(state(next_to_2(stateid('michigan')))),answer(state(next_to_2(stateid('michigan'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([704,-1.982610,answer(state(next_to_2(stateid('missouri')))),answer(state(next_to_2(stateid('missouri'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([705,-1.991230,answer(state(next_to_2(stateid('montana')))),answer(state(next_to_2(stateid('montana'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([706,-1.990050,answer(state(next_to_2(stateid('new hampshire')))),answer(state(next_to_2(stateid('new hampshire'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([707,-1.995380,answer(state(next_to_2(stateid('new jersey')))),answer(state(next_to_2(stateid('new jersey'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([708,-1.984120,answer(state(next_to_2(stateid('ohio')))),answer(state(next_to_2(stateid('ohio'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([709,-1.973120,answer(state(next_to_2(stateid('rhode island')))),answer(state(next_to_2(stateid('rhode island'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([710,-2.573550,answer(state(next_to_2(state(next_to_2(stateid('colorado')))))),answer(state(next_to_2(state(next_to_2(stateid('colorado'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([711,-2.571640,answer(state(next_to_2(state(next_to_2(stateid('mississippi')))))),answer(state(next_to_2(state(next_to_2(stateid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([712,-2.835000,answer(state(next_to_2(state(next_to_2(state(next_to_2(stateid('florida')))))))),answer(state(next_to_2(state(next_to_2(state(next_to_2(stateid('florida'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([713,-3.251060,answer(state(next_to_2(state(next_to_2(state(next_to_2(state(next_to_2(stateid('texas')))))))))),answer(state(next_to_2(state(next_to_2(state(next_to_2(state(next_to_2(stateid('texas'))))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([714,-3.256830,answer(state(next_to_2(state(next_to_2(largest_one(population_1(state(all)))))))),answer(state(next_to_2(state(next_to_2(largest_one(population_1(state(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([715,-2.579370,answer(state(next_to_2(state(traverse_1(riverid('mississippi')))))),answer(state(next_to_2(state(traverse_1(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([716,-2.654220,answer(state(next_to_2(state(traverse_1(riverid('ohio')))))),answer(state(next_to_2(state(traverse_1(riverid('ohio'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([717,-2.608300,answer(state(next_to_2(state(traverse_1(riverid('mississippi')))))),answer(state(next_to_2(state(traverse_1(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([718,-1.929610,answer(state(next_to_2(stateid('texas')))),answer(state(next_to_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([719,-2.928300,answer(intersection(state(next_to_2(stateid('texas'))), loc_1(major(river(all))))),answer(intersection(state(next_to_2(stateid('texas'))),loc_1(major(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([720,-2.535010,answer(state(next_to_2(river(riverid('mississippi'))))),answer(state(next_to_2(river(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([721,-2.514290,answer(state(next_to_2(largest_one(population_1(state(all)))))),answer(state(next_to_2(largest_one(population_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([722,-3.243280,answer(state(next_to_2(most(state(next_to_2(state(all))))))),answer(state(next_to_2(most(state(next_to_2(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([723,-2.722370,answer(state(next_to_2(most(state(loc_1(city(all))))))),answer(state(next_to_2(most(state(loc_1(city(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([724,-3.360990,answer(state(next_to_2(most(state(loc_1(major(city(all)))))))),answer(state(next_to_2(most(state(loc_1(major(city(all))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([725,-2.635990,answer(state(next_to_2(smallest_one(area_1(state(all)))))),answer(state(next_to_2(smallest_one(area_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([726,-2.722370,answer(state(next_to_2(most(state(loc_1(city(all))))))),answer(state(next_to_2(most(state(loc_1(city(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([727,-2.018400,answer(state(next_to_2(stateid('wisconsin')))),answer(state(next_to_2(stateid('wisconsin'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([728,-2.601780,answer(state(capital_2(cityid('dover', _)))),answer(state(capital_2(cityid('dover',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([729,-2.458690,answer(state(loc_1(major(river(all))))),answer(state(loc_1(major(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([730,-2.595720,answer(state(traverse_1(river(riverid('colorado'))))),answer(state(traverse_1(river(riverid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([731,-2.649910,answer(state(traverse_1(river(riverid('delaware'))))),answer(state(traverse_1(river(riverid('delaware')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([732,-2.615700,answer(state(traverse_1(river(riverid('mississippi'))))),answer(state(traverse_1(river(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([733,-2.513790,answer(state(traverse_1(riverid('mississippi')))),answer(state(traverse_1(riverid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([734,-2.604770,answer(state(traverse_1(river(riverid('missouri'))))),answer(state(traverse_1(river(riverid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([735,-2.522330,answer(state(traverse_1(riverid('missouri')))),answer(state(traverse_1(riverid('missouri'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([736,-2.613230,answer(state(traverse_1(river(riverid('ohio'))))),answer(state(traverse_1(river(riverid('ohio')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([737,-2.649700,answer(state(traverse_1(river(riverid('ohio'))))),answer(state(traverse_1(river(riverid('ohio')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([738,-2.561910,answer(state(traverse_1(shortest(river(all))))),answer(state(traverse_1(shortest(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([739,-3.161890,answer(state(loc_1(capital(highest(place(all)))))),answer(state(loc_1(capital(highest(place(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([740,-2.503580,answer(state(loc_1(city(cityid('austin', _))))),answer(state(loc_1(city(cityid('austin',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([741,-2.461780,answer(state(loc_1(city(cityid('austin', _))))),answer(state(loc_1(city(cityid('austin',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([742,-2.504410,answer(state(loc_1(city(cityid('dallas', _))))),answer(state(loc_1(city(cityid('dallas',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([743,-2.551110,answer(state(loc_1(city(cityid('plano', _))))),answer(state(loc_1(city(cityid('plano',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([744,-2.551470,answer(state(loc_1(city(cityid('portland', _))))),answer(state(loc_1(city(cityid('portland',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([745,-2.489980,answer(state(loc_1(city(cityid('rochester', _))))),answer(state(loc_1(city(cityid('rochester',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([746,-2.436340,answer(state(loc_1(city(cityid('salt lake city', _))))),answer(state(loc_1(city(cityid('salt lake city',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([747,-2.594770,answer(exclude(state(all), next_to_2(state(all)))),answer(exclude(state(all),next_to_2(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([748,-2.443770,answer(state(loc_1(river(riverid('colorado'))))),answer(state(loc_1(river(riverid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([749,-2.354880,answer(state(traverse_1(river(all)))),answer(state(traverse_1(river(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([750,-2.444100,answer(state(loc_1(city(cityid('springfield', _))))),answer(state(loc_1(city(cityid('springfield',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([751,-3.197700,answer(state(high_point_2(higher_2(high_point_1(stateid('colorado')))))),answer(state(high_point_2(higher_2(high_point_1(stateid('colorado'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([752,-3.321650,answer(intersection(state(loc_2(countryid('usa'))), loc_1(city(cityid('springfield', _))))),answer(intersection(state(loc_2(countryid('usa'))),loc_1(city(cityid('springfield',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([753,-1.952650,answer(state(next_to_2(stateid('maine')))),answer(state(next_to_2(stateid('maine'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([754,-2.017180,answer(state(next_to_2(stateid('kentucky')))),answer(state(next_to_2(stateid('kentucky'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([755,-2.539350,answer(largest_one(population_1(city(loc_2(stateid('texas')))))),answer(largest_one(population_1(city(loc_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([756,-1.781180,answer(largest(city(all))),answer(largest(city(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([757,-1.984520,answer(loc_1(mountain(all))),answer(loc_1(mountain(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([758,-1.886210,answer(loc_1(cityid('austin', _))),answer(loc_1(cityid('austin',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([759,-1.877250,answer(loc_1(cityid('baton rouge', _))),answer(loc_1(cityid('baton rouge',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([760,-1.872890,answer(loc_1(cityid('dallas', _))),answer(loc_1(cityid('dallas',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([761,-1.877250,answer(loc_1(cityid('fort wayne', _))),answer(loc_1(cityid('fort wayne',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([762,-1.913680,answer(loc_1(cityid('houston', _))),answer(loc_1(cityid('houston',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([763,-1.908670,answer(loc_1(cityid('indianapolis', _))),answer(loc_1(cityid('indianapolis',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([764,-1.975870,answer(loc_1(stateid('massachusetts'))),answer(loc_1(stateid('massachusetts')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([765,-1.927080,answer(loc_1(placeid('mount whitney'))),answer(loc_1(placeid('mount whitney')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([766,-1.913730,answer(loc_1(placeid('mount whitney'))),answer(loc_1(placeid('mount whitney')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([767,-1.968470,answer(loc_1(stateid('new hampshire'))),answer(loc_1(stateid('new hampshire')))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([768,-1.872080,answer(loc_1(cityid('new orleans', _))),answer(loc_1(cityid('new orleans',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([769,-1.914210,answer(loc_1(cityid('portland', _))),answer(loc_1(cityid('portland',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([770,-1.904560,answer(loc_1(cityid('san diego', _))),answer(loc_1(cityid('san diego',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([771,-1.898760,answer(loc_1(cityid('san jose', _))),answer(loc_1(cityid('san jose',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([772,-1.887220,answer(loc_1(cityid('scotts valley', _))),answer(loc_1(cityid('scotts valley',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([773,-1.911470,answer(loc_1(cityid('springfield', _))),answer(loc_1(cityid('springfield',_)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([774,-2.059440,answer(loc_1(river(riverid('chattahoochee')))),answer(loc_1(river(riverid('chattahoochee'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([775,-2.557030,answer(highest(mountain(loc_2(countryid('usa'))))),answer(highest(mountain(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([776,-2.530620,answer(highest(place(loc_2(stateid('hawaii'))))),answer(highest(place(loc_2(stateid('hawaii')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([777,-2.547420,answer(highest(place(loc_2(stateid('montana'))))),answer(highest(place(loc_2(stateid('montana')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([778,-2.564980,answer(lowest(place(loc_2(stateid('maryland'))))),answer(lowest(place(loc_2(stateid('maryland')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([779,-2.542640,answer(lowest(place(loc_2(countryid('usa'))))),answer(lowest(place(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([780,-2.493090,answer(lowest(place(loc_2(stateid('iowa'))))),answer(lowest(place(loc_2(stateid('iowa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([781,-2.473410,answer(largest_one(population_1(city(loc_2(stateid('new mexico')))))),answer(largest_one(population_1(city(loc_2(stateid('new mexico'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([782,-2.084360,answer(loc_1(smallest(city(all)))),answer(loc_1(smallest(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([783,-2.569530,answer(capital(loc_2(state(next_to_2(stateid('texas')))))),answer(capital(loc_2(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([784,-2.800040,answer(exclude(capital(all), major(city(all)))),answer(exclude(capital(all),major(city(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([785,-2.657120,answer(largest_one(population_1(city(loc_2(stateid('california')))))),answer(largest_one(population_1(city(loc_2(stateid('california'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([786,-4.027120,answer(density_1(state(traverse_1(longest(river(loc_2(countryid('usa')))))))),answer(density_1(state(traverse_1(longest(river(loc_2(countryid('usa'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([787,-2.867840,answer(highest(exclude(mountain(all), loc_2(stateid('alaska'))))),answer(highest(exclude(mountain(all),loc_2(stateid('alaska')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([788,-2.514000,answer(longest(river(loc_2(countryid('usa'))))),answer(longest(river(loc_2(countryid('usa')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([789,-3.282440,answer(lowest(place(loc_2(state(traverse_1(riverid('mississippi'))))))),answer(lowest(place(loc_2(state(traverse_1(riverid('mississippi')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([790,-1.899910,answer(shortest(river(all))),answer(shortest(river(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([791,-1.873700,answer(smallest(state(all))),answer(smallest(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([792,-3.281250,answer(largest_one(population_1(state(next_to_2(stateid('pennsylvania')))))),answer(largest_one(population_1(state(next_to_2(stateid('pennsylvania'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([793,-2.632570,answer(most(river(traverse_2(state(all))))),answer(most(river(traverse_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([794,-2.511300,answer(most(river(traverse_2(state(all))))),answer(most(river(traverse_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([795,-2.556210,answer(most(river(traverse_2(state(all))))),answer(most(river(traverse_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([796,-1.941780,answer(most(river(traverse_2(state(all))))),answer(most(river(traverse_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([797,-1.925470,answer(river(loc_2(stateid('alaska')))),answer(river(loc_2(stateid('alaska'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([798,-2.593510,answer(exclude(river(all), traverse_2(stateid('texas')))),answer(exclude(river(all),traverse_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([799,-2.612860,answer(exclude(river(all), traverse_2(countryid('usa')))),answer(exclude(river(all),traverse_2(countryid('usa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([800,-1.944310,answer(river(traverse_2(stateid('alaska')))),answer(river(traverse_2(stateid('alaska'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([801,-2.560670,answer(river(traverse_2(state(next_to_2(stateid('new mexico')))))),answer(river(traverse_2(state(next_to_2(stateid('new mexico'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([802,-3.321010,answer(river(traverse_2(state(next_to_2(state(loc_1(capital(cityid('austin', _))))))))),answer(river(traverse_2(state(next_to_2(state(loc_1(capital(cityid('austin',_)))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([803,-2.773240,answer(river(traverse_2(fewest(state(loc_1(city(all))))))),answer(river(traverse_2(fewest(state(loc_1(city(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([804,-3.201270,answer(river(traverse_2(state(loc_1(largest(city(loc_2(countryid('usa'))))))))),answer(river(traverse_2(state(loc_1(largest(city(loc_2(countryid('usa')))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([805,-3.208520,answer(river(traverse_2(state(loc_1(lowest(place(loc_2(countryid('usa'))))))))),answer(river(traverse_2(state(loc_1(lowest(place(loc_2(countryid('usa')))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([806,-2.004570,answer(state(next_to_2(stateid('kentucky')))),answer(state(next_to_2(stateid('kentucky'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([807,-1.977290,answer(state(next_to_2(stateid('florida')))),answer(state(next_to_2(stateid('florida'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([808,-1.948950,answer(state(next_to_2(stateid('hawaii')))),answer(state(next_to_2(stateid('hawaii'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([809,-1.987080,answer(most(state(next_to_2(state(all))))),answer(most(state(next_to_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([810,-2.577050,answer(most(state(next_to_2(state(all))))),answer(most(state(next_to_2(state(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([811,-2.602180,answer(smallest_one(population_1(capital(all)))),answer(smallest_one(population_1(capital(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([812,-1.962440,answer(most(state(loc_1(river(all))))),answer(most(state(loc_1(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([813,-2.454230,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([814,-2.455160,answer(largest_one(density_1(state(all)))),answer(largest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([815,-2.502080,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([816,-2.505410,answer(state(loc_1(highest(place(all))))),answer(state(loc_1(highest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([817,-2.373400,answer(state(loc_1(highest(place(all))))),answer(state(loc_1(highest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([818,-2.517760,answer(state(loc_1(highest(place(all))))),answer(state(loc_1(highest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([819,-2.433110,answer(largest_one(density_1(state(all)))),answer(largest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([820,-2.524050,answer(state(loc_1(largest(city(all))))),answer(state(loc_1(largest(city(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([821,-2.448020,answer(largest_one(density_1(state(all)))),answer(largest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([822,-2.467370,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([823,-2.571200,answer(state(loc_1(longest(river(all))))),answer(state(loc_1(longest(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([824,-2.522410,answer(state(loc_1(lowest(place(all))))),answer(state(loc_1(lowest(place(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([825,-2.755460,answer(state(loc_1(lowest(place(loc_2(next_to_2(stateid('idaho')))))))),answer(state(loc_1(lowest(place(loc_2(next_to_2(stateid('idaho'))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([826,-2.434590,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([827,-2.748960,answer(most(state(loc_1(major(city(all)))))),answer(most(state(loc_1(major(city(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([828,-2.667950,answer(most(state(loc_1(major(river(all)))))),answer(most(state(loc_1(major(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([829,-2.555640,answer(most(state(traverse_1(major(river(all)))))),answer(most(state(traverse_1(major(river(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([830,-2.492310,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([831,-2.468170,answer(largest_one(population_1(state(all)))),answer(largest_one(population_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([832,-2.593810,answer(most(state(loc_1(river(all))))),answer(most(state(loc_1(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([833,-2.406170,answer(most(state(traverse_1(river(all))))),answer(most(state(traverse_1(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([834,-2.588210,answer(state(loc_1(river(riverid('red'))))),answer(state(loc_1(river(riverid('red')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([835,-2.582870,answer(smallest_one(area_1(state(next_to_2(stateid('texas')))))),answer(smallest_one(area_1(state(next_to_2(stateid('texas'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([836,-2.329780,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([837,-2.451880,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([838,-2.467120,answer(smallest_one(density_1(state(all)))),answer(smallest_one(density_1(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([839,-1.992700,answer(state(loc_1(cityid('kalamazoo', _)))),answer(state(loc_1(cityid('kalamazoo',_))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([840,-2.552680,answer(state(loc_1(placeid('mount mckinley')))),answer(state(loc_1(placeid('mount mckinley'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([841,-2.729720,answer(state(loc_1(city(cityid('denver', _))))),answer(state(loc_1(city(cityid('denver',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([842,-2.583230,answer(state(loc_1(largest(city(loc_2(stateid('montana'))))))),answer(state(loc_1(largest(city(loc_2(stateid('montana')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([843,-1.857950,answer(smallest(state(all))),answer(smallest(state(all)))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([844,-1.935350,answer(state(next_to_2(stateid('alabama')))),answer(state(next_to_2(stateid('alabama'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([845,-1.994430,answer(state(next_to_2(stateid('alabama')))),answer(state(next_to_2(stateid('alabama'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([846,-1.976490,answer(state(next_to_2(stateid('alaska')))),answer(state(next_to_2(stateid('alaska'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([847,-1.962900,answer(state(next_to_2(stateid('arizona')))),answer(state(next_to_2(stateid('arizona'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([848,-1.944180,answer(state(next_to_2(stateid('colorado')))),answer(state(next_to_2(stateid('colorado'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([849,-1.948950,answer(state(next_to_2(stateid('hawaii')))),answer(state(next_to_2(stateid('hawaii'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([850,-1.977310,answer(state(next_to_2(stateid('illinois')))),answer(state(next_to_2(stateid('illinois'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([851,-1.971530,answer(state(next_to_2(stateid('iowa')))),answer(state(next_to_2(stateid('iowa'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([852,-2.004570,answer(state(next_to_2(stateid('kentucky')))),answer(state(next_to_2(stateid('kentucky'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([853,-1.987020,answer(state(next_to_2(stateid('michigan')))),answer(state(next_to_2(stateid('michigan'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([854,-1.983300,answer(state(next_to_2(stateid('new york')))),answer(state(next_to_2(stateid('new york'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([855,-2.720330,answer(exclude(state(all), next_to_2(state(all)))),answer(exclude(state(all),next_to_2(state(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([856,-1.941540,answer(state(next_to_2(stateid('south dakota')))),answer(state(next_to_2(stateid('south dakota'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([857,-2.565380,answer(state(next_to_2(state(traverse_1(riverid('mississippi')))))),answer(state(next_to_2(state(traverse_1(riverid('mississippi'))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([858,-1.907010,answer(state(next_to_2(stateid('texas')))),answer(state(next_to_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([859,-2.646560,answer(state(next_to_2(longest(river(loc_2(countryid('usa'))))))),answer(state(next_to_2(longest(river(loc_2(countryid('usa')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([860,-2.559370,answer(state(next_to_2(river(riverid('missouri'))))),answer(state(next_to_2(river(riverid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([861,-2.657790,answer(state(next_to_2(smallest_one(area_1(state(all)))))),answer(state(next_to_2(smallest_one(area_1(state(all))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([862,-2.878890,answer(state(loc_1(largest(city(capital_1(state(all))))))),answer(state(loc_1(largest(city(capital_1(state(all)))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([863,-2.413440,answer(state(traverse_1(river(riverid('colorado'))))),answer(state(traverse_1(river(riverid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([864,-2.591820,answer(exclude(state(all), next_to_2(stateid('texas')))),answer(exclude(state(all),next_to_2(stateid('texas'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([865,-2.613240,answer(state(traverse_1(river(riverid('chattahoochee'))))),answer(state(traverse_1(river(riverid('chattahoochee')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([866,-2.558380,answer(state(traverse_1(river(riverid('colorado'))))),answer(state(traverse_1(river(riverid('colorado')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([867,-2.496670,answer(state(traverse_1(longest(river(all))))),answer(state(traverse_1(longest(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([868,-2.491550,answer(state(traverse_1(longest(river(all))))),answer(state(traverse_1(longest(river(all)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([869,-2.580710,answer(state(traverse_1(river(riverid('mississippi'))))),answer(state(traverse_1(river(riverid('mississippi')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([870,-2.515300,answer(state(traverse_1(riverid('mississippi')))),answer(state(traverse_1(riverid('mississippi'))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([871,-2.573990,answer(state(traverse_1(river(riverid('missouri'))))),answer(state(traverse_1(river(riverid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([872,-2.567430,answer(state(traverse_1(river(riverid('missouri'))))),answer(state(traverse_1(river(riverid('missouri')))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([873,-2.582580,answer(state(loc_1(major(city(cityid('austin', _)))))),answer(state(loc_1(major(city(cityid('austin',_))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([874,-1.837260,answer(state(loc_1(river(all)))),answer(state(loc_1(river(all))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([875,-2.471160,answer(state(loc_1(city(cityid('austin', _))))),answer(state(loc_1(city(cityid('austin',_)))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([876,-3.091310,answer(state(loc_1(place(higher_2(highest(place(loc_2(stateid('colorado'))))))))),answer(state(loc_1(place(higher_2(highest(place(loc_2(stateid('colorado')))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([877,-3.073050,answer(state(loc_1(place(higher_2(highest(place(loc_2(stateid('texas'))))))))),answer(state(loc_1(place(higher_2(highest(place(loc_2(stateid('texas')))))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([878,-3.005930,answer(state(traverse_1(longest(river(loc_2(countryid('usa'))))))),answer(state(traverse_1(longest(river(loc_2(countryid('usa')))))))])),E,writeln('error')).

catch(call_with_time_limit(1,eval([879,-2.542610,answer(largest_one(density_1(city(all)))),answer(largest_one(density_1(city(all))))])),E,writeln('error')).

