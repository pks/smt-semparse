#!/bin/bash
cd /workspace/grounded/smt-semparse/working/2013-12-14T13.36.37/mert-work
/workspace/grounded/mosesdecoder/bin/extractor  --scconfig case:true  --scfile run5.scores.dat --ffile run5.features.dat -r /workspace/grounded/smt-semparse/working/2013-12-14T13.36.37/tune.mrl -n run5.best100.out.gz
